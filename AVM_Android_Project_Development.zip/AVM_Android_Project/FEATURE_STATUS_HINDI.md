# AVM Android Feature Port Status

| Feature | Status in current development project |
|---|---|
| USB OTG + GRBL 115200 | Basic implementation |
| Live status / coordinates | Basic implementation |
| X/Y/Z jog + independent speed | Basic implementation |
| Z ±40 mm jog command cap | Basic implementation; machine soft-limit validation pending |
| Pen UP/DOWN, Home, Unlock | Basic implementation |
| G-code open / sender / ACK | Basic implementation; planner-buffer protocol pending |
| Pause / Resume / Stop | Basic realtime requests; robust recovery pending |
| Checkpoint / restore | Snapshot hash + line count only; not safe physical resume yet |
| Preview / zoom | Basic XY path preview; current marker and executed-path state pending |
| Progress / ETA | Basic line count and ETA estimate |
| GRBL settings | `$$` read/log only; settings editor/history pending |
| CPU/RAM monitor | Basic RAM and process CPU-time display |
| Feed override | GRBL 1.1 realtime command buttons |
| Console-pasted job / Auto Flow | Not implemented yet |
| Preflight / machine-area analysis / Auto-Fit | Not implemented yet |
| Test drawing generator | Not implemented yet |
| Photo-to-G-code styles and image controls | Not implemented yet |
| Original-vs-preview compare | Not implemented yet |
| Auto Compare & Improve | Not implemented yet |
| Full desktop Python feature parity | Not complete |
