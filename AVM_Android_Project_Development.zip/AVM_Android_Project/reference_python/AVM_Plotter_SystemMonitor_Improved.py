# AVM Plotter - Arduino GRBL pen plotter control only
# Python 3.13 recommended
# Install:
#   py -3.13 -m pip install pyserial Pillow psutil  (psutil optional, for CPU/RAM monitor)
#
# Run:
#   py -3.13 AVM_Plotter.py
#
# Notes:
# - Arduino USB connect/disconnect and GRBL pen-plotter controls only.
# - Test with the pen lifted and low speeds first.

import os
import re
import math
import time
import bisect
import threading
import json
import hashlib

try:
    import psutil  # Optional: enables CPU/RAM telemetry in System Monitor.
except ImportError:
    psutil = None
import tempfile
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    serial = None
    list_ports = None


APP_TITLE = "AVM Plotter - GRBL Pen Plotter Controller"
BAUD_RATE = 115200
DEFAULT_XY_SPEED = 300
DEFAULT_Z_SPEED = 200
BG = "#fff4e6"
SAFFRON = "#e87512"
DARK = "#29221c"
GREEN = "#168447"
RED = "#bd3030"

GRBL_SETTING_HELP = {
 0:"Step pulse ki lambai microseconds mein; driver ko step signal kitni der diya jata hai.",
 1:"Motor idle delay milliseconds; command ke baad motor kitni der energized rahe.",
 2:"Step pulse ki polarity invert karna (bit mask). Aam taur par 0.",
 3:"Axis direction invert mask; motor ki direction ulatne ke liye bit mask.",
 4:"Step enable signal ki polarity invert.", 5:"Limit switch input ki polarity invert.",
 6:"Probe input ki polarity invert.", 10:"Status report mein machine/work position aur fields ka format.",
 11:"Junction deviation; corners par motion smoothness aur speed ko prabhavit karta hai.",
 12:"Arc tolerance; G2/G3 arc ko chhote segments mein approximate karne ki tolerance.",
 13:"Report units: 0=mm, 1=inches.", 20:"Soft limits ON/OFF; machine travel limit cross hone par alarm.",
 21:"Hard limits ON/OFF; limit switch trigger par alarm.",22:"Homing cycle ON/OFF.",
 23:"Homing direction invert mask; kis axis ki homing direction ulatni hai.",
 24:"Homing seek ke baad slow locate speed (mm/min).",25:"Homing seek speed (mm/min).",
 26:"Homing switch debounce delay milliseconds.",27:"Homing pull-off distance (mm).",
 30:"Spindle maximum RPM setting; pen plotter mein aam taur par istemal nahi.",
 31:"Spindle minimum RPM setting; pen plotter mein aam taur par istemal nahi.",
 32:"Laser mode ON/OFF; pen plotter ke liye aam taur par 0 rakhein.",
 100:"X axis steps per mm; calibration/steps calculation.",101:"Y axis steps per mm.",102:"Z axis steps per mm.",
 110:"X axis maximum rate mm/min.",111:"Y axis maximum rate mm/min.",112:"Z axis maximum rate mm/min.",
 120:"X axis acceleration mm/sec².",121:"Y axis acceleration mm/sec².",122:"Z axis acceleration mm/sec².",
 130:"X axis maximum travel mm.",131:"Y axis maximum travel mm.",132:"Z axis maximum travel mm."
}

# G-code number patterns (GRBL also accepts ".5" and "5.")
_NUM = r"(-?(?:\d+(?:\.\d*)?|\.\d+))"
AXIS_XYZF_RE = re.compile(r"([XYZF])\s*" + _NUM)
AXIS_XY_RE = re.compile(r"([XY])\s*" + _NUM)
Z_WORD_RE = re.compile(r"(?:^|\s)Z\s*" + _NUM)


class AVMAI:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1050x760")
        self.root.minsize(900, 650)
        self.root.configure(bg=BG)

        self.ser = None
        self.serial_lock = threading.RLock()
        self.stop_sender = threading.Event()
        self.graceful_stop = threading.Event()
        self.pause_sender = threading.Event()
        self.sender_thread = None
        self.gcode_path = None
        self.gcode_lines = []
        self.sender_busy = False
        self.z_reference_set = False
        self.z_position_from_reference = 0.0
        self.machine_width = None
        self.machine_height = None
        self.grbl_settings = {}
        self.settings_history = {}
        self.settings_read_busy = False
        self.settings_history_path = os.path.join(os.path.expanduser("~"), ".avm_grbl_settings_history.json")
        try:
            with open(self.settings_history_path, "r", encoding="utf-8") as hf:
                self.settings_history = json.load(hf)
        except Exception:
            self.settings_history = {}
        self.preview_pan_y = 0
        self.machine_position = {"X": None, "Y": None, "Z": None}
        self.preview_points = []
        self.preview_line_points = []
        self.preview_segments = []
        self.preview_seg_lines = []
        self.preview_items = []
        self.preview_progress_index = 0
        self._drawn_progress = 0
        self._preview_draw_token = 0
        self._preview_draw_after_id = None
        self._connecting = False
        self._pv = None
        self.preview_zoom = 1.0
        self.status_poll_busy = False
        self.feed_override_percent = 100
        self.pending_runtime_z = None
        self.runtime_control_lock = threading.Lock()
        self.job_absolute_mode = True
        self.job_last_feed = None
        self.job_started_at = None
        self.console_lines = []
        self.job_source = "file"
        self._last_completed_lines = 0
        self.checkpoint_path = os.path.join(os.path.expanduser("~"), ".avm_grbl_checkpoint.json")
        self._monitor_stop = threading.Event()
        self._monitor_thread = None
        self._monitor_after_id = None
        self._processing_status = "Idle"
        self._preview_status = "Idle"
        self._buffer_status = "Idle"
        self._buffer_bytes = 0
        self._log_max_lines = 2000

        self._build_ui()
        self.refresh_ports()
        self.log("AVM GRBL Controller ready. Arduino USB se connect karein.")
        if os.path.exists(self.checkpoint_path):
            try:
                with open(self.checkpoint_path, "r", encoding="utf-8") as f:
                    saved = json.load(f)
                self.log(f"Previous checkpoint found: line {saved.get('line')} / {saved.get('total')} at {saved.get('saved_at')}. Position verify/home karein; safe automatic resume abhi enabled nahi hai.")
            except Exception:
                self.log("Previous checkpoint file mila, lekin read nahi ho saka.")
        self.set_status("DISCONNECTED", RED)
        self.root.protocol("WM_DELETE_WINDOW", self.close_app)
        self.root.after(500, self.poll_machine_status)
        self.start_system_monitor()

    # ---------- UI ----------
    def _build_ui(self):
        header = tk.Frame(self.root, bg=SAFFRON, height=65)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(header, text="AVM PLOTTER", font=("Arial", 24, "bold"),
                 bg=SAFFRON, fg="white").pack(side="left", padx=20)
        tk.Label(header, text="MANUAL  •  G-CODE  •  GRBL PLOTTER",
                 font=("Arial", 11, "bold"), bg=SAFFRON, fg="white").pack(side="left", padx=10)
        self.alarm_banner = tk.Label(self.root, text="MACHINE STATUS: NOT CONNECTED",
                                     bg="#555555", fg="white", font=("Arial", 13, "bold"),
                                     anchor="w", padx=14, pady=7)
        self.alarm_banner.pack(fill="x")
        self.alarm_detail = tk.Label(self.root, text="Alarm details and recovery guidance will appear here.",
                                     bg="#eeeeee", fg=DARK, font=("Arial", 9), anchor="w", padx=14, pady=4)
        self.alarm_detail.pack(fill="x")
        safety_bar = tk.Frame(self.root, bg=BG)
        safety_bar.pack(fill="x", padx=12, pady=(4, 0))
        # Keep Console and GRBL settings controls visible near the top; they were
        # previously below the preview and could be clipped on smaller displays.
        quick_actions = ttk.Frame(self.root)
        quick_actions.pack(fill="x", padx=12, pady=(3, 2))
        ttk.Button(quick_actions, text="OPEN G-CODE CONSOLE", command=self.open_console_panel).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(quick_actions, text="READ GRBL SETTINGS ($$)", command=self.open_grbl_settings).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(safety_bar, text="UNLOCK ALARM ($X)", command=self.unlock_alarm).pack(side="left", padx=3)
        self.emergency_button = tk.Button(
            safety_bar, text="🚨 EMERGENCY STOP", command=self.emergency_stop,
            bg="#b00020", fg="white", activebackground="#7a0015",
            activeforeground="white", font=("Arial", 11, "bold"), relief="raised"
        )
        self.emergency_button.pack(side="right", padx=3)
        self.grbl_state = "Disconnected"
        self.last_alarm = None

        top = tk.Frame(self.root, bg=BG)
        top.pack(fill="x", padx=12, pady=10)

        conn = ttk.LabelFrame(top, text="Arduino USB Connection", padding=10)
        conn.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.port_var = tk.StringVar()
        self.port_box = ttk.Combobox(conn, textvariable=self.port_var, width=18, state="readonly")
        self.port_box.pack(side="left", padx=5)
        ttk.Button(conn, text="Refresh Ports", command=self.refresh_ports).pack(side="left", padx=4)
        ttk.Button(conn, text="Connect", command=self.connect_arduino).pack(side="left", padx=4)
        ttk.Button(conn, text="Disconnect", command=self.disconnect_arduino).pack(side="left", padx=4)
        self.status_label = tk.Label(conn, text="DISCONNECTED", fg=RED, bg=BG,
                                     font=("Arial", 10, "bold"))
        self.status_label.pack(side="left", padx=12)

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=12)

        # Left column is scrollable so no control gets clipped on small screens.
        left_outer = tk.Frame(body, bg=BG)
        left_outer.pack(side="left", fill="y", padx=(0, 10))
        left_canvas = tk.Canvas(left_outer, bg=BG, highlightthickness=0, width=320)
        left_scroll = ttk.Scrollbar(left_outer, orient="vertical", command=left_canvas.yview)
        left_canvas.configure(yscrollcommand=left_scroll.set)
        left_scroll.pack(side="right", fill="y")
        left_canvas.pack(side="left", fill="y")
        left = tk.Frame(left_canvas, bg=BG)
        left_canvas.create_window((0, 0), window=left, anchor="nw")

        def _left_configure(_event=None):
            left_canvas.configure(scrollregion=left_canvas.bbox("all"), width=left.winfo_reqwidth())
        left.bind("<Configure>", _left_configure)

        def _left_wheel(event):
            if left.winfo_reqheight() > left_canvas.winfo_height():
                left_canvas.yview_scroll(int(-event.delta / 120), "units")
        left_outer.bind("<Enter>", lambda _e: self.root.bind_all("<MouseWheel>", _left_wheel))
        left_outer.bind("<Leave>", lambda _e: self.root.unbind_all("<MouseWheel>"))

        manual = ttk.LabelFrame(left, text="Manual Axis Control", padding=10)
        manual.pack(fill="x", pady=5)
        ttk.Label(manual, text="Jog distance (mm)").grid(row=0, column=0, columnspan=3, sticky="w")
        self.jog_var = tk.StringVar(value="1")
        ttk.Combobox(manual, textvariable=self.jog_var,
                     values=("0.1", "0.5", "1", "2", "5", "10"),
                     width=8, state="readonly").grid(row=1, column=0, columnspan=1, sticky="w", pady=4)
        ttk.Label(manual, text="Z travel: ±40 mm from reference").grid(
            row=1, column=1, columnspan=2, sticky="w", padx=6)
        for axis, row in (("X", 2), ("Y", 4), ("Z", 6)):
            ttk.Label(manual, text=f"{axis} Axis").grid(row=row, column=0, columnspan=3, pady=(8, 2))
            ttk.Button(manual, text=f"{axis} −", width=10,
                       command=lambda a=axis: self.jog(a, -1)).grid(row=row+1, column=0, columnspan=1, padx=2)
            ttk.Button(manual, text=f"{axis} +", width=10,
                       command=lambda a=axis: self.jog(a, 1)).grid(row=row+1, column=1, columnspan=2, padx=2)
        ttk.Button(manual, text="Set Z Reference (current = 0)",
                   command=self.set_z_reference).grid(row=8, column=0, columnspan=3, sticky="ew", pady=(8, 2))
        self.z_range_label = ttk.Label(manual, text="Z reference not set")
        self.z_range_label.grid(row=9, column=0, columnspan=3, sticky="w")
        ttk.Button(manual, text="Home All ($H)", command=self.home_all).grid(
            row=10, column=0, columnspan=1, sticky="ew", padx=2, pady=(6, 0))
        ttk.Button(manual, text="Go to X0 Y0", command=self.go_work_zero).grid(
            row=10, column=1, columnspan=2, sticky="ew", padx=2, pady=(6, 0))

        speed = ttk.LabelFrame(left, text="Axis Speed (mm/min)", padding=10)
        speed.pack(fill="x", pady=5)
        self.speed_vars = {}
        self.speed_value_labels = {}
        self._last_speed_values = {"X": 700, "Y": 700, "Z": 300}
        speed_help = {
            "X": "X axis ki adhiktam chalne ki speed (mm/min). Zyada value = tez X movement; bahut zyada speed se vibration/step loss ho sakta hai.",
            "Y": "Y axis ki adhiktam chalne ki speed (mm/min). Zyada value = tez Y movement; machine ki mechanical limit ke andar rakhein.",
            "Z": "Pen lift/down axis ki adhiktam speed (mm/min). Zyada value = tez pen movement; pen mechanism ke hisaab se set karein."
        }
        for i, (axis, default) in enumerate((("X", 700), ("Y", 700), ("Z", 300))):
            ttk.Label(speed, text=f"{axis} speed").grid(row=i*2, column=0, sticky="w", pady=3)
            var = tk.StringVar(value=str(default))
            self.speed_vars[axis] = var
            ttk.Button(speed, text="−", width=3,
                       command=lambda a=axis: self.adjust_axis_speed(a, -50)).grid(row=i*2, column=1, padx=(4, 1))
            ttk.Entry(speed, textvariable=var, width=8).grid(row=i*2, column=2, padx=2)
            ttk.Button(speed, text="+", width=3,
                       command=lambda a=axis: self.adjust_axis_speed(a, 50)).grid(row=i*2, column=3, padx=1)
            ttk.Button(speed, text="Apply", command=lambda a=axis: self.apply_axis_speed(a)).grid(row=i*2, column=4, padx=2)
            old_new = ttk.Label(speed, text=f"Purani value: {default} | Nayi value: {default}", wraplength=280)
            old_new.grid(row=i*2+1, column=0, columnspan=5, sticky="w")
            self.speed_value_labels[axis] = old_new
            ttk.Label(speed, text=speed_help[axis], wraplength=285, foreground="#654").grid(
                row=i*2+2, column=0, columnspan=5, sticky="w", pady=(0, 5))

        ttk.Button(left, text="Pen UP (Z1)", command=lambda: self.pen_move(True)).pack(fill="x", pady=3)
        ttk.Button(left, text="Pen DOWN (Z0)", command=lambda: self.pen_move(False)).pack(fill="x", pady=3)

        zero_box = ttk.LabelFrame(left, text="Set Work Zero", padding=8)
        zero_box.pack(fill="x", pady=4)
        zero_row = tk.Frame(zero_box, bg=BG)
        zero_row.pack(fill="x")
        for axis in ("X", "Y", "Z"):
            ttk.Button(zero_row, text=f"{axis}0", command=lambda a=axis: self.set_axis_zero(a)).pack(side="left", expand=True, fill="x", padx=2)

        test_box = ttk.LabelFrame(left, text="Test Drawing Generator (10–200 mm)", padding=8)
        test_box.pack(fill="x", pady=4)
        self.test_shape_var = tk.StringVar(value="Square")
        self.test_size_var = tk.StringVar(value="20")
        ttk.Combobox(test_box, textvariable=self.test_shape_var, values=("Square", "Rectangle", "Triangle", "Circle", "Diagonal", "X Axis", "Y Axis", "Z Pen", "Border", "Accuracy"), state="readonly", width=12).pack(fill="x", pady=2)
        ttk.Spinbox(test_box, from_=10, to=200, increment=1, textvariable=self.test_size_var, width=10).pack(fill="x", pady=2)
        ttk.Button(test_box, text="Generate + Preview Test", command=self.generate_test_gcode).pack(fill="x", pady=2)
        ttk.Button(test_box, text="▶ RUN TEST CODE", command=self.run_test_gcode).pack(fill="x", pady=2)

        filebox = ttk.LabelFrame(left, text="G-code File", padding=10)
        filebox.pack(fill="x", pady=5)
        ttk.Button(filebox, text="Choose G-code", command=self.choose_gcode).pack(fill="x", pady=3)
        self.file_label = ttk.Label(filebox, text="No file selected", wraplength=230)
        self.file_label.pack(fill="x", pady=3)
        ttk.Button(filebox, text="▶ PLAY G-code", command=self.run_gcode).pack(fill="x", pady=3)
        self.auto_send_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(filebox, text="AUTO SEND: har GRBL ACK ke baad agli line turant bheje (safe continuous mode)",
                        variable=self.auto_send_var).pack(anchor="w", pady=2)
        row = tk.Frame(filebox, bg=BG)
        row.pack(fill="x")
        ttk.Button(row, text="Pause", command=self.pause_gcode).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(row, text="Resume", command=self.resume_gcode).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(row, text="■ STOP", command=self.stop_gcode).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(row, text="Next Line", command=self.send_next_line).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(filebox, text="Resume Stopped Job (checkpoint)", command=self.resume_stopped_job).pack(fill="x", pady=3)
        self.progress_var = tk.DoubleVar(value=0)
        self.progress_bar = ttk.Progressbar(filebox, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill="x", pady=(7, 2))
        self.progress_label = ttk.Label(filebox, text="Progress: 0%")
        self.progress_label.pack(fill="x")
        self.job_info_label = ttk.Label(filebox, text="Lines: —   Area: —")
        self.job_info_label.pack(fill="x", pady=(3, 0))
        override = tk.Frame(filebox, bg=BG)
        override.pack(fill="x", pady=(5, 0))
        ttk.Label(override, text="Feed override").pack(side="left")
        ttk.Button(override, text="−10%", width=6, command=lambda: self.adjust_feed_override(-10)).pack(side="left", padx=2)
        self.override_label = ttk.Label(override, text="100%")
        self.override_label.pack(side="left", padx=3)
        ttk.Button(override, text="+10%", width=6, command=lambda: self.adjust_feed_override(10)).pack(side="left", padx=2)
        ttk.Button(override, text="100%", width=5, command=self.reset_feed_override).pack(side="left", padx=2)

        live_controls = ttk.LabelFrame(filebox, text="RUNNING JOB CONTROL", padding=6)
        live_controls.pack(fill="x", pady=(7, 2))
        ttk.Label(live_controls, text="X/Y running speed (GRBL Feed Override)").pack(anchor="w")
        live_xy = tk.Frame(live_controls, bg=BG)
        live_xy.pack(fill="x", pady=2)
        ttk.Button(live_xy, text="X/Y −10%", command=lambda: self.adjust_feed_override(-10)).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(live_xy, text="X/Y +10%", command=lambda: self.adjust_feed_override(10)).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(live_xy, text="Reset 100%", command=self.reset_feed_override).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Label(live_controls, text="Z pen position while running (queued at next acknowledged line)").pack(anchor="w", pady=(4, 0))
        live_z = tk.Frame(live_controls, bg=BG)
        live_z.pack(fill="x")
        ttk.Button(live_z, text="Z UP (Z1)", command=lambda: self.request_runtime_pen(True)).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Button(live_z, text="Z DOWN (Z0)", command=lambda: self.request_runtime_pen(False)).pack(side="left", expand=True, fill="x", padx=2)
        ttk.Label(live_controls, text="Note: GRBL 1.1 feed override global hota hai; X/Y aur Z ke liye alag running override firmware support nahi karta.", wraplength=270).pack(anchor="w", pady=(3, 0))

        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="both", expand=True)

        machine = ttk.LabelFrame(right, text="Machine Position / Working Area", padding=8)
        machine.pack(fill="x", pady=5)
        self.position_label = ttk.Label(machine, text="Current Position: X —   Y —   Z —")
        self.position_label.pack(anchor="w")
        self.machine_area_label = ttk.Label(machine, text="Machine Area: GRBL settings read hone ka intezar...")
        self.machine_area_label.pack(anchor="w", pady=(3, 0))
        self.live_job_label = ttk.Label(machine, text="Pen Z: — mm   Feed: — mm/min   Override: 100%")
        self.live_job_label.pack(anchor="w", pady=(3, 0))

        preview = ttk.LabelFrame(right, text="Live Drawing Preview (G-code Path)", padding=6)
        preview.pack(fill="both", expand=True, pady=5)
        self.preview_canvas = tk.Canvas(preview, bg="#fffdf9", height=260, highlightthickness=1,
                                        highlightbackground="#c9b8a6")
        self.preview_canvas.pack(fill="both", expand=True)
        self.preview_canvas.bind("<Configure>", lambda _e: self.draw_preview())
        zoom_row = ttk.Frame(preview)
        zoom_row.pack(fill="x", pady=(3, 0))
        ttk.Button(zoom_row, text="− Zoom", command=lambda: self.change_preview_zoom(1/1.2)).pack(side="left", padx=2)
        self.zoom_label = ttk.Label(zoom_row, text="100%")
        self.zoom_label.pack(side="left", padx=5)
        ttk.Button(zoom_row, text="+ Zoom", command=lambda: self.change_preview_zoom(1.2)).pack(side="left", padx=2)
        ttk.Button(zoom_row, text="Fit / Reset", command=self.reset_preview_zoom).pack(side="left", padx=5)
        pan_row = ttk.Frame(preview)
        pan_row.pack(fill="x", pady=(2, 0))
        ttk.Button(pan_row, text="↑ Preview Upar", command=lambda: self.pan_preview(-25)).pack(side="left", padx=2)
        ttk.Button(pan_row, text="↓ Preview Neeche", command=lambda: self.pan_preview(25)).pack(side="left", padx=2)
        ttk.Button(pan_row, text="Center", command=self.center_preview).pack(side="left", padx=2)
        self.preview_hint = ttk.Label(preview, text="WORK ZERO = X0 Y0 (physical switch-home position firmware par depend karti hai) | START = drawing start | Green = complete | Orange = remaining | Red = live position")
        self.preview_hint.pack(anchor="w")

        self.console_window = None
        self.console_text = None
        self.settings_tree = None
        action_row = ttk.Frame(right)
        action_row.pack(fill="x", pady=4)
        ttk.Label(action_row, text="Console aur GRBL Settings ke shortcuts upar diye gaye hain.").pack(anchor="w")

        cmd = ttk.LabelFrame(right, text="Manual GRBL Command", padding=10)
        cmd.pack(fill="x", pady=5)
        self.command_var = tk.StringVar()
        entry = ttk.Entry(cmd, textvariable=self.command_var)
        entry.pack(side="left", fill="x", expand=True, padx=(0, 6))
        entry.bind("<Return>", lambda _e: self.send_manual_command())
        ttk.Button(cmd, text="Send", command=self.send_manual_command).pack(side="left")
        ttk.Button(cmd, text="Unlock ($X)", command=self.unlock_alarm).pack(side="left", padx=4)
        ttk.Button(cmd, text="Status (?)", command=lambda: self.send_command("?")).pack(side="left")

        logs = ttk.LabelFrame(right, text="AVM Controller Activity / GRBL Messages", padding=8)
        logs.pack(fill="both", expand=True, pady=5)
        self.log_box = tk.Text(logs, height=25, wrap="word", bg="#fffdf9", fg=DARK,
                               font=("Consolas", 10), state="disabled")
        self.log_box.pack(fill="both", expand=True)
        monitor = ttk.LabelFrame(self.root, text="AVM SYSTEM MONITOR", padding=6)
        monitor.pack(fill="x", padx=12, pady=(2, 4))
        self.monitor_cpu_label = ttk.Label(monitor, text="CPU: checking…")
        self.monitor_cpu_label.grid(row=0, column=0, sticky="w", padx=8, pady=2)
        self.monitor_ram_label = ttk.Label(monitor, text="RAM: checking…")
        self.monitor_ram_label.grid(row=0, column=1, sticky="w", padx=8, pady=2)
        self.monitor_usb_label = ttk.Label(monitor, text="USB: disconnected")
        self.monitor_usb_label.grid(row=0, column=2, sticky="w", padx=8, pady=2)
        self.monitor_buffer_label = ttk.Label(monitor, text="G-code In-flight: idle")
        self.monitor_buffer_label.grid(row=1, column=0, sticky="w", padx=8, pady=2)
        self.monitor_processing_label = ttk.Label(monitor, text="Processing: idle")
        self.monitor_processing_label.grid(row=1, column=1, sticky="w", padx=8, pady=2)
        self.monitor_preview_label = ttk.Label(monitor, text="Preview: idle")
        self.monitor_preview_label.grid(row=1, column=2, sticky="w", padx=8, pady=2)
        for col in range(3):
            monitor.columnconfigure(col, weight=1)

        bottom = tk.Label(self.root,
                          text="Safety: pehle pen lifted rakhein, chhota test karein. Emergency mein machine ka physical power switch use karein.",
                          bg=BG, fg="#8a3d16", font=("Arial", 9, "bold"))
        bottom.pack(fill="x", padx=14, pady=8)

    # ---------- System Monitor (telemetry only; never controls machine motion) ----------
    def start_system_monitor(self):
        if self._monitor_thread and self._monitor_thread.is_alive():
            return
        self._monitor_stop.clear()
        self._monitor_thread = threading.Thread(
            target=self._system_monitor_worker, name="AVM-SystemMonitor", daemon=True
        )
        self._monitor_thread.start()
        self._refresh_monitor_labels()

    def _system_monitor_worker(self):
        process = None
        if psutil is not None:
            try:
                process = psutil.Process(os.getpid())
                process.cpu_percent(interval=None)  # prime non-blocking CPU counter
            except Exception:
                process = None
        while not self._monitor_stop.wait(1.0):
            cpu_text = "CPU: unavailable"
            ram_text = "RAM: unavailable"
            if psutil is not None:
                try:
                    cpu = psutil.cpu_percent(interval=0.15)
                    vm = psutil.virtual_memory()
                    proc_mb = process.memory_info().rss / (1024 * 1024) if process else 0
                    cpu_text = f"CPU: {cpu:.0f}%"
                    ram_text = f"RAM: {vm.percent:.0f}% used | AVM {proc_mb:.0f} MB"
                except Exception:
                    pass
            self.ui(self._set_monitor_resource_labels, cpu_text, ram_text)
            self.ui(self._refresh_monitor_labels)

    def _set_monitor_resource_labels(self, cpu_text, ram_text):
        if not self.root.winfo_exists():
            return
        self.monitor_cpu_label.config(text=cpu_text)
        self.monitor_ram_label.config(text=ram_text)

    def _refresh_monitor_labels(self):
        if not hasattr(self, "monitor_usb_label"):
            return
        try:
            connected = bool(self.ser and self.ser.is_open)
        except Exception:
            connected = False
        self.monitor_usb_label.config(text=f"USB: {'Connected' if connected else 'Disconnected'}")
        if self.sender_busy:
            buffer_text = f"{self._buffer_status} ({self._buffer_bytes} B in-flight)"
        else:
            buffer_text = self._buffer_status or "Idle"
        self.monitor_buffer_label.config(text=f"G-code In-flight: {buffer_text}")
        processing = "Paused" if self.pause_sender.is_set() else self._processing_status
        self.monitor_processing_label.config(text=f"Processing: {processing}")
        self.monitor_preview_label.config(text=f"Preview: {self._preview_status}")

    def open_console_panel(self):
        if self.console_window is not None and self.console_window.winfo_exists():
            self.console_window.deiconify()
            self.console_window.lift()
            return
        win = tk.Toplevel(self.root)
        self.console_window = win
        win.title("AVM G-code Console")
        win.geometry("850x280")
        win.transient(self.root)
        ttk.Label(win, text="Multi-line G-code paste karein; Run dabane par Smart Check ke baad ACK-safe sender chalega.").pack(anchor="w", padx=8, pady=5)
        self.console_text = tk.Text(win, height=10, wrap="none", font=("Consolas", 10))
        self.console_text.pack(fill="both", expand=True, padx=8, pady=4)
        row = ttk.Frame(win)
        row.pack(fill="x", padx=8, pady=5)
        ttk.Button(row, text="Run Console G-code", command=self.run_console_gcode).pack(side="left", padx=3)
        ttk.Button(row, text="Clear", command=lambda: self.console_text.delete("1.0", "end")).pack(side="left", padx=3)
        ttk.Button(row, text="Close", command=win.withdraw).pack(side="right", padx=3)

    def ui(self, fn, *args):
        # Background workers may finish while the window is closing.
        try:
            if self.root.winfo_exists():
                self.root.after(0, lambda: fn(*args) if self.root.winfo_exists() else None)
        except tk.TclError:
            pass

    def log(self, msg):
        stamp = time.strftime("%H:%M:%S")
        self.log_box.configure(state="normal")
        self.log_box.insert("end", f"[{stamp}] {msg}\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def pan_preview(self, pixels):
        self.preview_pan_y = max(-500, min(500, self.preview_pan_y + int(pixels)))
        self.draw_preview()

    def center_preview(self):
        self.preview_pan_y = 0
        self.draw_preview()

    def change_preview_zoom(self, factor):
        self.preview_zoom = max(0.25, min(5.0, self.preview_zoom * factor))
        if hasattr(self, "zoom_label"):
            self.zoom_label.configure(text=f"{self.preview_zoom*100:.0f}%")
        self.draw_preview()

    def reset_preview_zoom(self):
        self.preview_zoom = 1.0
        if hasattr(self, "zoom_label"):
            self.zoom_label.configure(text="100%")
        self.draw_preview()

    def unlock_alarm(self):
        if not self.ser or not self.ser.is_open:
            messagebox.showwarning("Unlock", "Pehle Arduino connect karein.")
            return
        if self.sender_busy:
            messagebox.showwarning("Unlock", "Job active hai. Pehle job ko stop karein; running job ke beech unlock na karein.")
            return
        if not str(getattr(self, "grbl_state", "")).lower().startswith("alarm"):
            if not messagebox.askyesno("GRBL Unlock", "GRBL abhi Alarm state report nahi kar raha. Phir bhi $X bhejna hai?"):
                return
        elif not messagebox.askyesno("Alarm Unlock", "Pehle obstruction/limit switch/alarm ka karan door karein. $X sirf lock clear karta hai; homing/position ko theek nahi karta. Unlock bhejein?"):
            return
        self.send_command("$X")
        self.log("Unlock ($X) request bheji. Status/response verify karein; zarurat ho to homing karein.")

    def emergency_stop(self):
        if not self.ser or not self.ser.is_open:
            self.stop_sender.set()
            self.log("EMERGENCY: sender ko local taur par roka; Arduino disconnected hai. Physical power switch use karein.")
            return
        if not messagebox.askyesno(
            "EMERGENCY STOP",
            "Emergency action: GRBL Feed Hold (!) aur Soft Reset (Ctrl+X) bheja jayega. Isse motion abort hoga, queued G-code clear hoga aur machine position uncertain ho sakti hai. Physical power cutoff/E-stop switch bhi use karein. Continue?"
        ):
            return
        self.stop_sender.set()
        self.graceful_stop.set()
        self.pause_sender.clear()
        with self.runtime_control_lock:
            self.pending_runtime_z = None
        try:
            # Realtime feed hold first, then reset to discard commands already queued in GRBL.
            self.send_raw(b"!")
            time.sleep(0.12)
            self.send_raw(bytes([0x18]))
            self.log("🚨 EMERGENCY: Feed Hold + GRBL soft reset sent. Position is now UNVERIFIED; re-home/verify before motion.")
            self.show_machine_state("Alarm", "Emergency reset ke baad machine position uncertain hai. Physical inspection aur homing/position verification ke bina resume na karein.")
        except Exception as exc:
            self.log(f"Emergency command failed: {exc}. Physical power switch immediately use karein.")

    def set_status(self, text, color):
        self.status_label.config(text=text, fg=color)

    def show_machine_state(self, state, detail=""):
        self.grbl_state = state
        if state.lower().startswith("alarm"):
            self.last_alarm = state
            self.alarm_banner.configure(text=f"⚠ ALARM: {state}", bg="#b00020", fg="white")
            code = re.search(r"ALARM:?\s*(\d+)", state, re.I)
            code = code.group(1) if code else "?"
            causes = {
                "1": ("Hard limit / motion exceeded machine limit", "Limit switches, direction, homing and $130/$131 travel settings check karein; obstruction hataayein. Unlock sirf cause clear hone ke baad."),
                "2": ("Soft limit exceeded", "G-code coordinates, work zero, offsets aur machine travel check karein; file ko bed ke andar fit karein."),
                "3": ("Reset while in motion", "USB/power/reset interruption hua ho sakta hai. Position uncertain hai; homing/position verification ke bina resume na karein."),
                "4": ("Probe fail / initial state issue", "Probe wiring, probe input aur command ki starting position check karein."),
                "5": ("Homing not enabled", "$22=1 aur homing limit switches/configuration verify karein; switch wiring check karein."),
                "6": ("Homing fail: reset during cycle", "Limit switch wiring, motor direction, travel aur homing seek/pull-off settings check karein."),
                "7": ("Homing fail: door/limit state", "Limit/door input wiring aur switch state check karein; obstruction hataayein."),
                "8": ("Homing fail: pull-off not clear", "Limit switch release aur $27 pull-off distance check karein."),
                "9": ("Homing fail: could not find limit", "Axis direction, switch position/wiring, $25 seek rate aur travel settings check karein."),
            }
            cause, remedy = causes.get(code, ("GRBL ne alarm report kiya hai.", "Alarm code, wiring, limit switches, machine obstruction aur GRBL settings check karein. Cause clear kiye bina resume na karein."))
            self.alarm_detail.configure(text=f"KARAN: {cause}   |   NIVARAN: {remedy}", bg="#ffe5e5", fg="#7a0015")
        elif state.lower() == "alarm":
            self.last_alarm = "ALARM (code not included in status report)"
            self.alarm_banner.configure(text="⚠ ALARM: GRBL MACHINE LOCKED", bg="#b00020", fg="white")
            self.alarm_detail.configure(text="KARAN: GRBL alarm state report kar raha hai, lekin status packet mein code nahi hai. | NIVARAN: Activity log mein ALARM:n code dekhein; limit switch/obstruction/wiring aur G-code bounds check karein. Cause clear hone se pehle Unlock/Resume na karein.", bg="#ffe5e5", fg="#7a0015")
        elif state.lower() in ("idle", "run", "hold", "door", "check", "home", "jog", "sleep"):
            colors = {"idle": "#168447", "run": "#168447", "hold": "#b36b00", "door": "#b36b00", "check": "#555555", "home": "#555555", "jog": "#168447", "sleep": "#555555"}
            self.alarm_banner.configure(text=f"MACHINE STATUS: {state.upper()}", bg=colors.get(state.lower(), "#555555"), fg="white")
            self.alarm_detail.configure(text=detail or "Koi active GRBL alarm nahi hai.", bg="#eeeeee", fg=DARK)
        elif state == "Disconnected":
            self.alarm_banner.configure(text="MACHINE STATUS: DISCONNECTED", bg="#555555", fg="white")
            self.alarm_detail.configure(text="USB connect karein. Alarm history clear nahi ki gayi.", bg="#eeeeee", fg=DARK)

    def announce(self, message):
        # Voice temporarily disabled; keep all notifications visible in the activity log.
        self.log(message)

    # ---------- G-code text parsing (shared by file / console / loaders) ----------
    @staticmethod
    def parse_gcode_lines(raw_lines):
        """Strip comments / % markers, upper-case, and normalise G00..G03 to G0..G3."""
        lines = []
        for raw in raw_lines:
            line = raw.strip()
            if not line or line.startswith(";") or line.startswith("(") or line.startswith("%"):
                continue
            line = line.split(";")[0]
            line = re.sub(r"\([^)]*\)", "", line).strip().upper()
            if not line:
                continue
            line = re.sub(r"\bG0([0-3])\b", r"G\1", line)
            lines.append(line)
        return lines

    def pen_move(self, up):
        if self.sender_busy:
            self.log("G-code chal raha hai; pen manual move abhi blocked hai.")
            return
        self.send_command("G21 G90 G1 Z1 F200" if up else "G21 G90 G1 Z0 F200")

    def home_all(self):
        if self.sender_busy:
            self.log("Job chal raha hai; homing abhi blocked hai.")
            return
        if not self.ser or not self.ser.is_open:
            messagebox.showwarning("Arduino", "Pehle Arduino connect karein.")
            return
        if messagebox.askyesno("Home All ($H)", "GRBL homing ($H) sabhi axes ko home karta hai. Limit switch/homing enable na ho to error:5 aayega.\n\nPen lifted hai? Aage badhein?"):
            self.send_command("$H")

    def go_work_zero(self):
        if self.sender_busy:
            self.log("Job chal raha hai; X0 Y0 par jaana abhi blocked hai.")
            return
        if not self.ser or not self.ser.is_open:
            messagebox.showwarning("Arduino", "Pehle Arduino connect karein.")
            return
        self.send_command("G21 G90 G0 Z1")
        self.send_command("G90 G0 X0 Y0")

    def set_axis_zero(self, axis):
        if self.sender_busy:
            self.log("Job chal raha hai; work zero set karne se pehle pause/stop karein.")
            return
        if not self.ser or not self.ser.is_open:
            messagebox.showwarning("Arduino", "Pehle Arduino connect karein.")
            return
        if messagebox.askyesno("Set Work Zero", f"Current {axis} position ko work coordinate {axis}=0 set karein?"):
            self.send_command(f"G10 L20 P1 {axis}0")
            self.log(f"Work zero set request: {axis}=0")

    def adjust_feed_override(self, delta):
        if not self.ser or not self.ser.is_open:
            self.log("Feed override ke liye Arduino connect karein.")
            return
        # GRBL 1.1 real-time feed override: 0x91 = +10%, 0x92 = -10%.
        command = b"\x91" if delta > 0 else b"\x92"
        try:
            for _ in range(max(1, abs(delta) // 10)):
                self.send_raw(command)
            self.feed_override_percent = max(10, min(200, self.feed_override_percent + delta))
            self.override_label.config(text=f"{self.feed_override_percent}%")
            self.log(f"Feed override request: {self.feed_override_percent}%")
        except Exception as exc:
            self.log(f"Feed override error: {exc}")

    def request_runtime_pen(self, up):
        """Queue an absolute pen-height command; sender executes it only between ACKed G-code lines."""
        if not self.sender_busy:
            messagebox.showinfo("Z Pen", "Z UP/DOWN while-running control ke liye pehle G-code job start karein. Manual Pen UP/DOWN alag available hai.")
            return
        if not self.ser or not self.ser.is_open:
            messagebox.showwarning("Arduino", "Arduino connection active nahi hai.")
            return
        target = 1.0 if up else 0.0
        try:
            zfeed = int(float(self.speed_vars["Z"].get()))
            if not 1 <= zfeed <= 3000:
                raise ValueError
        except ValueError:
            messagebox.showwarning("Z Speed", "Z speed 1–3000 mm/min rakhein.")
            return
        with self.runtime_control_lock:
            self.pending_runtime_z = (target, zfeed)
        self.log(f"Z {'UP' if up else 'DOWN'} requested. Current G-code line ka ACK aane par queue se execute hoga.")

    def _execute_pending_runtime_z(self):
        with self.runtime_control_lock:
            request = self.pending_runtime_z
            self.pending_runtime_z = None
        if request is None:
            return
        target, zfeed = request
        if not self.ser or not self.ser.is_open:
            raise RuntimeError("Runtime Z command se pehle USB disconnect ho gaya.")
        # Preserve the current distance mode and modal feed as far as the sender can determine.
        command = f"G90 G1 Z{target:g} F{zfeed}"
        with self.serial_lock:
            self.ser.write((command + "\n").encode("ascii"))
            self.ser.flush()
        self.ui(self.log, f">> [LIVE Z] {command}")
        reply = self._read_grbl_reply(timeout=60)
        if reply == "STOPPED" or reply.lower().startswith(("error:", "alarm:")):
            raise RuntimeError(f"Live Z command failed: {reply}")
        if self.job_last_feed is not None:
            restore_feed = f"F{self.job_last_feed:g}"
            with self.serial_lock:
                self.ser.write((restore_feed + "\n").encode("ascii"))
                self.ser.flush()
            self.ui(self.log, f">> [LIVE Z] {restore_feed} (feed restored)")
            feed_reply = self._read_grbl_reply(timeout=60)
            if feed_reply != "ok":
                raise RuntimeError(f"Feed restore failed: {feed_reply}")
        if not self.job_absolute_mode:
            restore = "G91"
            with self.serial_lock:
                self.ser.write((restore + "\n").encode("ascii"))
                self.ser.flush()
            self.ui(self.log, f">> [LIVE Z] {restore} (distance mode restored)")
            restore_reply = self._read_grbl_reply(timeout=60)
            if restore_reply != "ok":
                raise RuntimeError(f"G91 restore failed: {restore_reply}")
        self.ui(self.log, f"Live Z command complete: Z{target:g}")

    def reset_feed_override(self):
        try:
            self.send_raw(b"\x90")  # GRBL reset feed override to 100%.
            self.feed_override_percent = 100
            self.override_label.config(text="100%")
            self.log("Feed override reset request: 100%")
        except Exception as exc:
            self.log(f"Feed override error: {exc}")

    def generate_test_gcode(self):
        # Clear stale test state first so a failed generation can never run an old test.
        self.gcode_path = None
        self.gcode_lines = []
        try:
            size = float(self.test_size_var.get())
            if not 10 <= size <= 200:
                raise ValueError("Size 10 mm se 200 mm ke beech hona chahiye.")
        except Exception as exc:
            messagebox.showwarning("Test size", str(exc))
            return False
        shape = self.test_shape_var.get()
        half = size / 2.0
        lines = ["G21", "G90", "G94", "G0 Z1"]
        if shape == "Square":
            pts = [(0, 0), (size, 0), (size, size), (0, size), (0, 0)]
        elif shape == "Rectangle":
            pts = [(0, 0), (size, 0), (size, size * 0.6), (0, size * 0.6), (0, 0)]
        elif shape == "Triangle":
            pts = [(0, 0), (size, 0), (half, size), (0, 0)]
        elif shape == "Diagonal":
            pts = [(0, 0), (size, size)]
        elif shape == "X Axis":
            pts = [(0, 0), (size, 0)]
        elif shape == "Y Axis":
            pts = [(0, 0), (0, size)]
        elif shape in ("Z Pen", "Accuracy"):
            pts = [(0, 0), (size, 0), (size, size), (0, size), (0, 0)]
        elif shape == "Border":
            pts = [(0, 0), (size, 0), (size, size * 0.6), (0, size * 0.6), (0, 0)]
        else:
            radius = half
            pts = [(half + radius * math.cos(2 * math.pi * i / 72),
                    half + radius * math.sin(2 * math.pi * i / 72)) for i in range(73)]
        # Pen stays UP while travelling; Z0 is the user's configured pen-down convention.
        lines.append(f"G0 X{pts[0][0]:.3f} Y{pts[0][1]:.3f}")
        if shape == "Z Pen":
            lines.extend(["G1 Z0 F200", "G4 P0.5", "G1 Z1 F200", "G4 P0.5"] * 5)
        else:
            lines.append("G1 Z0 F200")
            lines.extend(f"G1 X{x:.3f} Y{y:.3f} F300" for x, y in pts[1:])
        lines.extend(["G0 Z1", "G0 X0 Y0"])
        width, height, _ = self.estimate_job_area(lines)
        if (self.machine_width and width > self.machine_width) or (self.machine_height and height > self.machine_height):
            messagebox.showwarning("Machine area", f"Test {size:g} mm ka hai, jo machine area {self.machine_width} × {self.machine_height} mm se bada ho sakta hai.")
            return False
        fd, path = tempfile.mkstemp(prefix="AVM_Test_", suffix=".gcode", text=True)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        self.gcode_path = path
        self.file_label.config(text=f"TEST: {shape} {size:g} mm")
        self.gcode_lines = lines
        self.job_source = "file"
        self.job_info_label.config(text=f"Test: {shape} {size:g} mm   Lines: {len(lines)}")
        self.build_preview_path(lines)
        self.preview_hint.config(text="START = shuruaat | Hara = complete | Orange = baaki drawing | Grey dashed = pen-up travel | Red LIVE = actual machine position. Test origin X0 Y0.")
        self.log(f"{shape} {size:g} mm test G-code generated and previewed. Play dabane se pehle pen/work origin check karein.")
        return True

    def run_test_gcode(self):
        # Always generate from the currently selected test shape/size; do not
        # accidentally re-run an older file or previous test.
        generated = self.generate_test_gcode()
        if not generated or not self.gcode_lines or not self.gcode_path:
            return
        if not self.ser or not self.ser.is_open:
            messagebox.showwarning("Arduino", "Test code ban gaya hai. Run karne ke liye pehle Arduino connect karein.")
            return
        if self.sender_busy:
            messagebox.showinfo("Test Code", "Ek job pehle se chal raha hai.")
            return
        self.job_source = "file"
        self.review_gcode_before_run(self.gcode_lines, "AVM Test Drawing")

    # ---------- Smart G-code machine compatibility / repair ----------
    def analyze_gcode_for_machine(self, lines):
        """Conservative preflight. Static checks cannot guarantee physical safety."""
        issues = []
        warnings = []
        x = y = z = 0.0
        absolute = True
        unit_scale = 1.0
        motion = None
        min_x = max_x = x
        min_y = max_y = y
        min_z = max_z = z
        has_arc = False
        for n, raw in enumerate(lines, 1):
            line = raw.upper().strip()
            if not line:
                continue
            if len(line) > 75:
                warnings.append((n, f'Line {len(line)} characters ki hai; GRBL ki limit ~80 hai, line truncate/error ho sakti hai.'))
            if re.search(r'\bG20\b', line): unit_scale = 25.4
            if re.search(r'\bG21\b', line): unit_scale = 1.0
            if re.search(r'\bG90\b', line): absolute = True
            if re.search(r'\bG91\b', line): absolute = False
            if re.search(r'\bG0\b', line): motion = 'G0'
            if re.search(r'\bG1\b', line): motion = 'G1'
            if re.search(r'\bG2\b|\bG3\b', line):
                has_arc = True
                warnings.append((n, 'Arc (G2/G3) mila; exact curved path/bounds ka static estimate limited hai.'))
            if re.search(r'\bG38\.|\bG43\b|\bG49\b|\bG53\b|\bG54\b|\bG55\b|\bG56\b|\bG57\b|\bG58\b|\bG59\b', line):
                warnings.append((n, 'Coordinate/probe/tool mode mila; active offsets/tool state verify karein.'))
            words = {m.group(1): float(m.group(2)) for m in AXIS_XYZF_RE.finditer(line)}
            if 'F' in words:
                f = words['F'] * unit_scale
                if f <= 0: issues.append((n, 'Feed rate F zero ya negative hai.'))
                elif f > 20000: warnings.append((n, f'Feed rate bahut zyada lag raha hai: F{f:g}.'))
            for axis in ('X', 'Y', 'Z'):
                if axis in words:
                    val = words[axis] * unit_scale
                    if absolute:
                        if axis == 'X': x = val
                        elif axis == 'Y': y = val
                        else: z = val
                    else:
                        if axis == 'X': x += val
                        elif axis == 'Y': y += val
                        else: z += val
            min_x, max_x = min(min_x, x), max(max_x, x)
            min_y, max_y = min(min_y, y), max(max_y, y)
            min_z, max_z = min(min_z, z), max(max_z, z)
            if motion is None and any(a in words for a in 'XYZ'):
                warnings.append((n, 'Axis coordinate mila lekin modal motion (G0/G1) file mein pehle set nahi dikha.'))
        if self.machine_width and (min_x < -0.001 or max_x > self.machine_width + 0.001):
            issues.append((0, f'X range {min_x:.2f}..{max_x:.2f} mm machine travel 0..{self.machine_width:.2f} mm se bahar hai.'))
        if self.machine_height and (min_y < -0.001 or max_y > self.machine_height + 0.001):
            issues.append((0, f'Y range {min_y:.2f}..{max_y:.2f} mm machine travel 0..{self.machine_height:.2f} mm se bahar hai.'))
        if not self.machine_width or not self.machine_height:
            warnings.append((0, 'GRBL $130/$131 machine travel read nahi hua; area limit verify nahi ho saki.'))
        if min_z < -40 or max_z > 40:
            warnings.append((0, f'Z range {min_z:.2f}..{max_z:.2f} mm hai. App ka manual Z reference ±40 mm hai, lekin ye actual machine Z travel ka proof nahi.'))
        if not any(re.search(r'\bG90\b|\bG91\b', q.upper()) for q in lines):
            warnings.append((0, 'G90/G91 mode explicitly set nahi hai; GRBL ki pichhli modal state par nirbhar ho sakta hai.'))
        if not any(re.search(r'\bG20\b|\bG21\b', q.upper()) for q in lines):
            warnings.append((0, 'G20/G21 units explicitly set nahi hain; GRBL ki pichhli unit state par nirbhar ho sakti hai.'))
        if has_arc:
            warnings.append((0, 'Arc path ka full geometry preflight exact verify nahi karta.'))
        warnings.append((0, 'Work zero, clamps, pen mechanism, belt direction, actual Z limits aur physical clearance software se poori tarah verify nahi ho sakte.'))
        return issues, warnings, (min_x, max_x, min_y, max_y, min_z, max_z)

    def review_gcode_before_run(self, lines, source_label):
        issues, warnings, bounds = self.analyze_gcode_for_machine(lines)
        win = tk.Toplevel(self.root)
        win.title('AVM Smart G-code Check / Edit')
        win.geometry('850x650')
        win.transient(self.root)
        win.grab_set()
        ttk.Label(win, text=f'Machine Compatibility Check — {source_label}', font=('Arial', 13, 'bold')).pack(anchor='w', padx=10, pady=(10, 4))
        summary = f"XY: X {bounds[0]:.2f}..{bounds[1]:.2f} mm, Y {bounds[2]:.2f}..{bounds[3]:.2f} mm | Z: {bounds[4]:.2f}..{bounds[5]:.2f} mm | Lines: {len(lines)}"
        ttk.Label(win, text=summary, wraplength=810).pack(anchor='w', padx=10, pady=3)
        report = tk.Text(win, height=9, wrap='word', font=('Arial', 9))
        report.pack(fill='x', padx=10, pady=5)

        def fill_report():
            report.configure(state='normal')
            report.delete('1.0', 'end')
            report.insert('end', f"{'🔴 PROBLEM' if issues else '🟢 No hard static limit issue detected'}\n")
            for ln, msg in issues:
                report.insert('end', f"Line {ln if ln else '—'}: {msg}\n")
            report.insert('end', f"\n{'🟡 WARNINGS' if warnings else 'No warnings'}\n")
            for ln, msg in warnings:
                report.insert('end', f"Line {ln if ln else '—'}: {msg}\n")
            report.configure(state='disabled')
        fill_report()
        ttk.Label(win, text='Neeche G-code edit kar sakte hain. Re-check dabane par poori file dobara machine ke hisaab se check hogi.').pack(anchor='w', padx=10)
        editor = tk.Text(win, height=16, wrap='none', font=('Consolas', 9))
        editor.pack(fill='both', expand=True, padx=10, pady=5)
        editor.insert('1.0', '\n'.join(lines))
        state = {'approved': False, 'lines': None}

        def get_lines():
            return [q.strip() for q in editor.get('1.0', 'end').splitlines() if q.strip()]

        def recheck():
            nonlocal issues, warnings, bounds
            current = get_lines()
            issues, warnings, bounds = self.analyze_gcode_for_machine(current)
            fill_report()
            messagebox.showinfo('AVM Re-check', f'Jaanch poori. Problems: {len(issues)}, Warnings: {len(warnings)}.', parent=win)

        def run_now():
            current = get_lines()
            if not current:
                messagebox.showwarning('G-code', 'Code khaali hai.', parent=win)
                return
            now_issues, now_warnings, _ = self.analyze_gcode_for_machine(current)
            if now_issues or now_warnings:
                detail = 'Static check mein problem/warning abhi bhi hai. Machine damage ka risk ho sakta hai.\n\n'
                detail += '\n'.join([m for _, m in now_issues + now_warnings][:8])
                if not messagebox.askyesno('Run despite warning?', detail + '\n\nKya aap phir bhi run karna chahte hain? Sirf tab jab aapne machine area, zero aur clearance physically verify kar liya ho.', parent=win):
                    return
            state['approved'] = True
            state['lines'] = current
            win.destroy()

        def avm_auto_fit_xy():
            current = get_lines()
            # Only offer coordinate scaling when the file is explicitly absolute-mm
            # and contains no arcs/relative positioning; otherwise the transformation
            # could silently change the drawing.
            joined = '\n'.join(current).upper()
            if not re.search(r'\bG90\b', joined) or not re.search(r'\bG21\b', joined) or re.search(r'\bG91\b|\bG20\b|\bG2\b|\bG3\b|\bG10\b|\bG28\b|\bG30\b|\bG53\b|\bG92\b', joined):
                messagebox.showwarning('Auto-fix unavailable', 'AVM is file ko safely auto-scale nahi kar sakta. G-code mein G90 + G21 explicit hona chahiye aur G91/G20/arcs nahi hone chahiye. Aap editor mein manually correction kar sakte hain.', parent=win)
                return
            if not self.machine_width or not self.machine_height:
                messagebox.showwarning('Machine area missing', 'GRBL $130/$131 settings nahi mili. Pehle Arduino connect karke machine area read karayein.', parent=win)
                return
            _, _, b = self.analyze_gcode_for_machine(current)
            xmin, xmax, ymin, ymax = b[0], b[1], b[2], b[3]
            w = max(0.001, xmax - xmin)
            h = max(0.001, ymax - ymin)
            usable_w = self.machine_width * 0.95
            usable_h = self.machine_height * 0.95
            factor = min(1.0, usable_w / w, usable_h / h)
            if factor >= 0.999 and xmin >= 0 and ymin >= 0 and xmax <= usable_w and ymax <= usable_h:
                messagebox.showinfo('Auto-fix', 'XY path pehle se machine area ke andar hai. Koi scaling zaroori nahi.', parent=win)
                return
            if not messagebox.askyesno('Confirm AVM Auto-Fix', f'AVM XY drawing ko uniformly {factor*100:.1f}% scale karega aur minimum X/Y ko 0.5 mm margin par shift karega. Isse drawing ka size badal sakta hai. Work-zero aur clamps phir bhi aapko verify karne honge.\n\nApply karein?', parent=win):
                return
            fixed = []
            for line in current:
                def replace_axis(match):
                    axis = match.group(1).upper()
                    value = float(match.group(2))
                    if axis == 'X':
                        value = (value - xmin) * factor + 0.5
                    else:
                        value = (value - ymin) * factor + 0.5
                    return f'{axis}{value:.3f}'
                fixed.append(AXIS_XY_RE.sub(replace_axis, line.upper()))
            editor.delete('1.0', 'end')
            editor.insert('1.0', '\n'.join(fixed))
            recheck()
            messagebox.showinfo('AVM Auto-Fix', 'XY coordinates machine bed ke 95% usable area mein fit karne ke liye scale/shift kiye. Original file overwrite nahi hui; preview aur re-check zaroor dekhein.', parent=win)

        buttons = ttk.Frame(win)
        buttons.pack(fill='x', padx=10, pady=8)
        ttk.Button(buttons, text='Re-check edited code', command=recheck).pack(side='left', padx=3)
        ttk.Button(buttons, text='AVM Auto-Fit XY', command=avm_auto_fit_xy).pack(side='left', padx=3)
        ttk.Button(buttons, text='Run after confirmation', command=run_now).pack(side='left', padx=3)
        ttk.Button(buttons, text='Cancel', command=win.destroy).pack(side='right', padx=3)
        win.wait_window()
        if state['approved']:
            self.gcode_lines = state['lines']
            self.build_preview_path(self.gcode_lines)
            self._start_job(self.gcode_lines)
            self.log(f'Smart G-code review approved. {len(self.gcode_lines)} lines run ke liye bheji gayi.')
            return True
        return False

    def run_console_gcode(self):
        if not self.ser or not self.ser.is_open:
            messagebox.showwarning("Arduino", "Pehle Arduino USB connect karein.")
            return
        if self.sender_busy:
            messagebox.showinfo("G-code", "Ek job pehle se chal raha hai.")
            return
        if self.console_text is None:
            self.open_console_panel()
            return
        lines = self.parse_gcode_lines(self.console_text.get("1.0", "end").splitlines())
        if not lines:
            messagebox.showwarning("Console", "Pehle G-code paste karein.")
            return
        self.job_source = "console"
        self.review_gcode_before_run(lines, "Console G-code")
        if not self.sender_busy:
            self.log("Console G-code review cancel ki gayi ya run approve nahi hua.")

    def _start_job(self, lines, start_index=0):
        # Save the exact reviewed/edited G-code; the original file may be different.
        snapshot_path = self.checkpoint_path + ".job.gcode"
        if start_index == 0:
            temp_path = snapshot_path + ".tmp"
            try:
                with open(temp_path, "w", encoding="utf-8", newline="\\n") as snapshot:
                    snapshot.write("\\n".join(lines) + "\\n")
                os.replace(temp_path, snapshot_path)
                with open(snapshot_path, "rb") as sf:
                    self._job_snapshot_sha256 = hashlib.sha256(sf.read()).hexdigest()
                if os.path.exists(self.checkpoint_path):
                    os.remove(self.checkpoint_path)
            except Exception as exc:
                try:
                    if os.path.exists(temp_path):
                        os.remove(temp_path)
                except Exception:
                    pass
                messagebox.showerror("Job snapshot", f"Reviewed G-code snapshot save nahi hui; job start nahi kiya.\\n{exc}")
                return False
        self.gcode_lines = list(lines)
        self.stop_sender.clear()
        self.graceful_stop.clear()
        self.pause_sender.clear()
        self._last_completed_lines = start_index
        self._job_start_index = start_index
        self._single_step_event = threading.Event()
        self._job_auto_send = bool(self.auto_send_var.get()) if hasattr(self, "auto_send_var") else True
        self.job_absolute_mode = True
        self.job_last_feed = None
        with self.runtime_control_lock:
            self.pending_runtime_z = None
        self.z_reference_set = False
        self.z_range_label.config(text="Z reference needed after G-code run")
        self.update_progress(start_index / max(1, len(lines)) * 100, start_index, len(lines))
        self.preview_progress_index = bisect.bisect_right(self.preview_seg_lines, start_index)
        self.refresh_preview_progress()
        self.sender_busy = True
        self._processing_status = "Sending G-code"
        self._buffer_status = "Ready"
        self.ui(self._refresh_monitor_labels)
        self.file_label.configure(foreground=GREEN)
        self.file_label.configure(text=f"▶ RUNNING: {self.file_label.cget('text')}")
        self.job_started_at = time.time()
        self.sender_thread = threading.Thread(target=self._send_gcode_worker, daemon=True)
        self.sender_thread.start()
        return True


    def set_z_reference(self):
        if self.sender_busy:
            self.log("G-code run ho raha hai; abhi Z reference set nahi kar sakte.")
            return
        if not self.ser or not self.ser.is_open:
            messagebox.showwarning("Arduino", "Pehle Arduino USB connect karein.")
            return
        if messagebox.askyesno("Set Z Reference", "Kya Z axis abhi jis jagah hai use Z=0 maana jaye?\n\nIs reference se manual Z jog ko -40 se +40 mm tak limit kiya jayega."):
            if self.send_command("G10 L20 P1 Z0"):
                self.z_position_from_reference = 0.0
                self.z_reference_set = True
                self.z_range_label.config(text="Z position: 0.0 mm  |  allowed: -40 to +40 mm")
                self.log("Z reference command sent. GRBL response/physical position verify karein.")

    # ---------- USB / GRBL ----------
    def refresh_ports(self):
        if not list_ports:
            self.log("pyserial missing. Install: py -3.13 -m pip install pyserial")
            return
        ports = [p.device for p in list_ports.comports()]
        self.port_box["values"] = ports
        if ports and self.port_var.get() not in ports:
            self.port_var.set(ports[0])
        if not ports:
            self.port_var.set("")
        self.log("COM ports: " + (", ".join(ports) if ports else "koi port nahi mila"))

    def connect_arduino(self):
        """Open USB in a worker so serial startup delays never freeze Tk."""
        if not serial:
            messagebox.showerror("Missing library", "pyserial install karein.")
            return
        if self._connecting:
            self.log("USB connection pehle se start ho raha hai.")
            return
        port = self.port_var.get().strip()
        if not port:
            self.refresh_ports()
            messagebox.showwarning("USB port", "Pehle Arduino ka COM port select karein.")
            return
        if self.sender_busy:
            messagebox.showwarning("Arduino", "G-code job ke dauran reconnect na karein.")
            return
        self.disconnect_arduino(silent=True)
        self._connecting = True
        self.set_status(f"CONNECTING: {port}", "#b36b00")
        self.log(f"{port} se background mein connect ho raha hai...")
        threading.Thread(target=self._connect_worker, args=(port,), daemon=True).start()

    def _connect_worker(self, port):
        opened = None
        error = None
        try:
            opened = serial.Serial(port, BAUD_RATE, timeout=0.10, write_timeout=1)
            time.sleep(2)  # Arduino reset-on-open; worker thread only
            opened.reset_input_buffer()
        except Exception as exc:
            error = str(exc)
            try:
                if opened:
                    opened.close()
            except Exception:
                pass
        self.ui(self._connect_finished, port, opened, error)

    def _connect_finished(self, port, opened, error):
        self._connecting = False
        if error or opened is None:
            self.ser = None
            self.set_status("DISCONNECTED", RED)
            self.log(f"Connect error: {error or 'Unknown error'}")
            messagebox.showerror("Connection error", error or "USB connection failed")
            return
        self.ser = opened
        self.set_status(f"CONNECTED: {port}", GREEN)
        self.show_machine_state("Idle", f"Connected to {port} at {BAUD_RATE} baud. Status report ka intezar...")
        self.announce(f"Arduino successfully Connect ho gaya hai: {port} @ {BAUD_RATE}")
        # GRBL $$ query can take seconds; keep it off the UI thread too.
        threading.Thread(target=self.read_machine_settings, daemon=True).start()

    def disconnect_arduino(self, silent=False):
        if self.sender_busy and not silent:
            messagebox.showwarning("Arduino", "G-code job chal raha hai. Pehle STOP dabayein; line-boundary stop hone ke baad Disconnect karein.")
            return
        with self.serial_lock:
            if self.ser:
                try:
                    self.ser.close()
                except Exception:
                    pass
                self.ser = None
        self.set_status("DISCONNECTED", RED)
        self.show_machine_state("Disconnected")
        if not silent:
            self.log("Arduino disconnected.")

    def read_machine_settings(self):
        """Read every setting returned by GRBL $$, then refresh the settings window."""
        found = {}
        acquired_read_lock = False
        try:
            if self.sender_busy:
                self.ui(self.log, "GRBL settings read abhi nahi ho sakti: G-code job chal raha hai. Job complete/stop hone ke baad READ GRBL SETTINGS ($$) dabayein.")
                return
            if self.settings_read_busy:
                self.ui(self.log, "GRBL settings read pehle se chal rahi hai; kripya intezar karein.")
                return
            self.settings_read_busy = True
            acquired_read_lock = True
            with self.serial_lock:
                if not self.ser or not self.ser.is_open:
                    self.ui(self.log, "GRBL settings read nahi hui: Arduino connected nahi hai.")
                    return
                # Drain stale status/command replies before requesting the complete $$ list.
                self.ser.reset_input_buffer()
                self.ser.write(b"$$\n")
                self.ser.flush()
                deadline = time.time() + 8.0
                while time.time() < deadline:
                    raw = self.ser.readline()
                    if not raw:
                        continue
                    line = raw.decode("ascii", errors="ignore").strip()
                    m = re.match(r"\$(\d+)=(-?[0-9]+(?:\.[0-9]+)?)", line)
                    if m:
                        found[m.group(1)] = m.group(2)
                    if line.lower() == "ok":
                        break
            if found:
                self.grbl_settings.update(found)
                if "130" in found:
                    self.machine_width = float(found["130"])
                if "131" in found:
                    self.machine_height = float(found["131"])
                self.ui(self._record_settings_history, found)
                self.ui(self._refresh_settings_tree)
                self.ui(self.update_machine_area_label)
                self.ui(self.log, f"GRBL $$ read complete: {len(found)} settings mili. X travel=${found.get('130', 'N/A')} mm, Y travel=${found.get('131', 'N/A')} mm.")
            else:
                self.ui(self.log, "GRBL $$ ka response nahi mila. USB/baud rate/GRBL connection check karein.")
        except Exception as exc:
            self.ui(self.log, f"GRBL settings read error: {exc}")
        finally:
            if acquired_read_lock:
                self.settings_read_busy = False

    def _record_settings_history(self, values):
        for key, value in values.items():
            old = self.settings_history.get(key, [])
            if not old or str(old[-1]) != str(value):
                old.append(str(value))
            self.settings_history[key] = old[-3:]
        try:
            with open(self.settings_history_path, "w", encoding="utf-8") as hf:
                json.dump(self.settings_history, hf, ensure_ascii=False, indent=2)
        except Exception as exc:
            self.log(f"Settings history save error: {exc}")

    def _refresh_settings_tree(self):
        tree = getattr(self, "settings_tree", None)
        if tree is None or not tree.winfo_exists():
            return
        keys = sorted(set(GRBL_SETTING_HELP) | {int(x) for x in self.grbl_settings if str(x).isdigit()})
        for k in keys:
            cur = self.grbl_settings.get(str(k), "—")
            hist = ", ".join(self.settings_history.get(str(k), [])[-3:]) or "—"
            values = (f"${k}", cur, hist, GRBL_SETTING_HELP.get(k, "Is firmware setting ka detailed description available nahi."), "")
            if tree.exists(str(k)):
                tree.item(str(k), values=values)
            else:
                tree.insert("", "end", iid=str(k), values=values)

    def open_grbl_settings(self):
        if not self.ser or not self.ser.is_open:
            messagebox.showwarning("GRBL Settings", "Pehle Arduino USB connect karein, phir READ GRBL SETTINGS ($$) dabayein.")
            return
        if self.sender_busy:
            messagebox.showwarning("GRBL Settings", "G-code job chal raha hai. Settings read karne se serial replies mix ho sakte hain. Job stop/complete hone ke baad kholein.")
            return
        win = tk.Toplevel(self.root)
        win.title("AVM GRBL Settings — Hindi Guide & History")
        win.geometry("1120x680")
        top = ttk.Frame(win); top.pack(fill="x", padx=8, pady=6)
        ttk.Label(top, text="GRBL $$ Settings — Hindi matlab, current value aur pichhli 3 readings", font=("Arial", 11, "bold")).pack(side="left")
        ttk.Button(top, text="READ / REFRESH $$ NOW", command=lambda: threading.Thread(target=self.read_machine_settings, daemon=True).start()).pack(side="right")
        cols = ("id", "current", "history", "meaning", "new")
        tree = ttk.Treeview(win, columns=cols, show="headings", height=23)
        for col, title, width in (("id","Setting",75),("current","Current",90),("history","Pichhli 3 values",160),("meaning","Hindi mein matlab",600),("new","Nayi value",100)):
            tree.heading(col, text=title); tree.column(col, width=width, anchor="w")
        tree.pack(fill="both", expand=True, padx=8, pady=4)
        self.settings_tree = tree
        self._refresh_settings_tree()
        edit = ttk.Frame(win); edit.pack(fill="x", padx=8, pady=8)
        ttk.Label(edit, text="Selected setting number:").pack(side="left")
        sid = tk.StringVar(); val = tk.StringVar()
        ttk.Entry(edit, textvariable=sid, width=8).pack(side="left", padx=4)
        ttk.Label(edit, text="New value:").pack(side="left")
        ttk.Entry(edit, textvariable=val, width=14).pack(side="left", padx=4)
        def select_row(_event=None):
            sel = tree.selection()
            if sel:
                sid.set(sel[0]); val.set("")
        tree.bind("<<TreeviewSelect>>", select_row)
        def apply_setting():
            try:
                k = int(sid.get()); v = float(val.get())
                if k not in GRBL_SETTING_HELP and str(k) not in self.grbl_settings:
                    raise ValueError("Unknown setting number")
                if not math.isfinite(v):
                    raise ValueError("Invalid value")
            except Exception as exc:
                messagebox.showwarning("Setting", f"Setting number/value check karein: {exc}", parent=win); return
            old_value = self.grbl_settings.get(str(k), "unknown")
            if not messagebox.askyesno("Confirm GRBL setting", f"${k}: {old_value} → {v:g}\n\nGalat value se machine movement badal sakti hai. Apply karein?", parent=win):
                return
            self.send_command(f"${k}={v:g}")
            self.log(f"GRBL setting change requested: ${k}={v:g}; READ / REFRESH $$ NOW se accepted value verify karein.")
            win.after(900, lambda: threading.Thread(target=self.read_machine_settings, daemon=True).start())
        ttk.Button(edit, text="Apply Selected Setting", command=apply_setting).pack(side="left", padx=8)
        ttk.Label(win, text="Note: History mein $$ se mili pichhli 3 alag values save hoti hain. Apply ke baad GRBL response verify karne ke liye dobara READ / REFRESH $$ NOW dabayein.", foreground="#8a3d16", wraplength=1050).pack(anchor="w", padx=10, pady=(0,8))
        # Automatically query $$ when this dedicated settings page opens.
        threading.Thread(target=self.read_machine_settings, daemon=True).start()

    def update_machine_area_label(self):
        if self.machine_width is not None and self.machine_height is not None:
            self.machine_area_label.config(
                text=f"Machine Working Area (GRBL $130/$131): {self.machine_width:g} × {self.machine_height:g} mm")
        else:
            self.machine_area_label.config(text="Machine Area: $130/$131 GRBL settings unavailable; $$ check karein")
        self.draw_preview()

    def poll_machine_status(self):
        """Read GRBL real-time status only when the G-code sender is not consuming replies."""
        if self.ser and self.ser.is_open and not self.sender_busy and not self.status_poll_busy:
            self.status_poll_busy = True
            threading.Thread(target=self._status_poll_worker, daemon=True).start()
        if self.root.winfo_exists():
            self.root.after(500, self.poll_machine_status)

    def _status_poll_worker(self):
        try:
            with self.serial_lock:
                if not self.ser or not self.ser.is_open:
                    return
                self.ser.write(b"?")
                self.ser.flush()
                deadline = time.time() + 0.35
                while time.time() < deadline:
                    raw = self.ser.readline()
                    if not raw:
                        continue
                    line = raw.decode("ascii", errors="ignore").strip()
                    state_match = re.match(r"<([^|>]+)", line)
                    if state_match:
                        state_text = state_match.group(1)
                        if state_text.lower().startswith("alarm"):
                            self.ui(self.show_machine_state, state_text.upper())
                        else:
                            self.ui(self.show_machine_state, state_text)
                    elif line.upper().startswith("ALARM:"):
                        self.ui(self.show_machine_state, line.upper())
                    match = re.search(r"(?:MPos|WPos):(-?[0-9.]+),(-?[0-9.]+),(-?[0-9.]+)", line)
                    if match:
                        self.machine_position = dict(zip(("X", "Y", "Z"), map(float, match.groups())))
                        self.ui(self.update_position_label)
                        break
                    elif line:
                        # ok / error: / ALARM: replies to manual commands become visible in the log.
                        self.ui(self.log, f"<< {line}")
        except Exception as exc:
            self.ui(self.log, f"Status read: {exc}")
        finally:
            self.status_poll_busy = False

    def update_position_label(self):
        vals = self.machine_position

        def fmt(axis):
            value = vals.get(axis)
            return "—" if value is None else f"{value:.2f}"
        self.position_label.config(text=f"Current Position: X {fmt('X')} mm   Y {fmt('Y')} mm   Z {fmt('Z')} mm")
        z = vals.get("Z")
        self.live_job_label.config(text=f"Pen Z: {'—' if z is None else f'{z:.2f}'} mm   Feed: G-code F value   Override: {self.feed_override_percent}%")
        self._draw_live_marker()

    def _read_position_during_job(self):
        """Get a fresh GRBL position report from the sender thread after an acknowledged line."""
        try:
            with self.serial_lock:
                if not self.ser or not self.ser.is_open:
                    return
                self.ser.write(b"?")
                self.ser.flush()
                deadline = time.time() + 0.5
                while time.time() < deadline:
                    raw = self.ser.readline()
                    if not raw:
                        continue
                    line = raw.decode("ascii", errors="ignore").strip()
                    state_match = re.match(r"<([^|>]+)", line)
                    if state_match:
                        state_text = state_match.group(1)
                        if state_text.lower().startswith("alarm"):
                            self.ui(self.show_machine_state, state_text.upper())
                        else:
                            self.ui(self.show_machine_state, state_text)
                    elif line.upper().startswith("ALARM:"):
                        self.ui(self.show_machine_state, line.upper())
                    match = re.search(r"(?:MPos|WPos):(-?[0-9.]+),(-?[0-9.]+),(-?[0-9.]+)", line)
                    if match:
                        self.machine_position = dict(zip(("X", "Y", "Z"), map(float, match.groups())))
                        self.ui(self.update_position_label)
                        return
        except Exception as exc:
            self.ui(self.log, f"Position update: {exc}")

    def build_preview_path(self, lines):
        """Build a line-by-line preview, distinguishing pen-down drawing and pen-up travel."""
        x = y = 0.0
        absolute = True
        scale_units = 1.0
        motion = "G0"
        pen_down = False
        points = [(x, y)]
        segments = []
        for line_no, line in enumerate(lines, start=1):
            u = line.upper()
            if re.search(r"(?:^|\s)G90(?:\s|$)", u): absolute = True
            if re.search(r"(?:^|\s)G91(?:\s|$)", u): absolute = False
            if re.search(r"(?:^|\s)G20(?:\s|$)", u): scale_units = 25.4
            if re.search(r"(?:^|\s)G21(?:\s|$)", u): scale_units = 1.0
            if re.search(r"(?:^|\s)G0(?:\s|$)", u): motion = "G0"
            if re.search(r"(?:^|\s)G1(?:\s|$)", u): motion = "G1"
            z_match = Z_WORD_RE.search(u)
            if z_match:
                # AVM convention: Z0/down, positive Z/up.
                pen_down = float(z_match.group(1)) <= 0.001
            words = {m.group(1): float(m.group(2)) * scale_units for m in AXIS_XY_RE.finditer(u)}
            nx, ny = x, y
            if "X" in words: nx = words["X"] if absolute else x + words["X"]
            if "Y" in words: ny = words["Y"] if absolute else y + words["Y"]
            if nx != x or ny != y:
                kind = "draw" if motion == "G1" and pen_down else "travel"
                segments.append((x, y, nx, ny, kind, line_no))
                x, y = nx, ny
                points.append((x, y))
        self.preview_points = points
        self.preview_line_points = points[1:]
        self.preview_segments = segments
        self.preview_seg_lines = [s[5] for s in segments]
        self.preview_progress_index = 0
        self.draw_preview()

    def _update_count_text(self):
        """Update preview/job summary safely; called after batched preview drawing."""
        try:
            total_lines = len(getattr(self, "gcode_lines", []) or [])
            total_segments = len(getattr(self, "preview_segments", []) or [])
            done_segments = min(int(getattr(self, "preview_progress_index", 0) or 0), total_segments)
            if total_segments:
                pct = (done_segments / total_segments) * 100.0
                summary = f"Preview: {total_segments} moves | Complete: {done_segments} ({pct:.1f}%) | G-code lines: {total_lines}"
            else:
                summary = f"Preview: no movement segments | G-code lines: {total_lines}"
            label = getattr(self, "job_info_label", None)
            if label is not None and label.winfo_exists():
                label.config(text=summary)
        except Exception as exc:
            # A missing/destroyed preview label must never break preview rendering.
            try:
                self.log(f"Preview count update skipped: {exc}")
            except Exception:
                pass

    def draw_preview(self):
        """Redraw preview in small UI batches; large jobs must not freeze Tk."""
        if not hasattr(self, "preview_canvas"):
            return
        c = self.preview_canvas
        self._preview_draw_token += 1
        token = self._preview_draw_token
        if self._preview_draw_after_id is not None:
            try:
                self.root.after_cancel(self._preview_draw_after_id)
            except Exception:
                pass
            self._preview_draw_after_id = None
        c.delete("all")
        self.preview_items = []
        self._preview_status = "Rendering"
        self._refresh_monitor_labels()
        w = max(100, c.winfo_width())
        h = max(100, c.winfo_height())
        pad = 28
        if self.machine_width and self.machine_height:
            xmin, ymin, xmax, ymax = 0.0, 0.0, self.machine_width, self.machine_height
        elif self.preview_points:
            xs = [p[0] for p in self.preview_points]
            ys = [p[1] for p in self.preview_points]
            xmin, xmax = min(0.0, min(xs)), max(1.0, max(xs))
            ymin, ymax = min(0.0, min(ys)), max(1.0, max(ys))
        else:
            xmin, ymin, xmax, ymax = 0.0, 0.0, 100.0, 100.0
        sx = (w - 2 * pad) / max(1e-9, xmax - xmin)
        sy = (h - 2 * pad) / max(1e-9, ymax - ymin)
        fit_scale = min(sx, sy)
        scale = fit_scale * self.preview_zoom
        bed_w = (xmax - xmin) * scale
        bed_h = (ymax - ymin) * scale
        left = (w - bed_w) / 2
        top = (h - bed_h) / 2 + self.preview_pan_y
        self._pv = {"left": left, "top": top, "bed_h": bed_h, "scale": scale, "xmin": xmin, "ymin": ymin}
        c.create_rectangle(left, top, left + bed_w, top + bed_h, outline="#777", width=2)
        c.create_text(left + 5, top + 5, text="MACHINE WORK AREA", anchor="nw", fill="#1769aa", font=("Arial", 9, "bold"))
        c.create_oval(left - 5, top + bed_h - 5, left + 5, top + bed_h + 5, fill="#1769aa", outline="white", width=1, tags="home_marker")
        c.create_text(left + 8, top + bed_h - 8, text="WORK ZERO (X0,Y0)", anchor="sw", fill="#1769aa", font=("Arial", 8, "bold"), tags="home_marker")

        def xy(px, py):
            return left + (px - xmin) * scale, top + bed_h - (py - ymin) * scale

        done_n = min(self.preview_progress_index, len(self.preview_segments))
        self._drawn_progress = done_n
        batch_size = 250
        def draw_batch(offset=0):
            if token != self._preview_draw_token or not c.winfo_exists():
                return
            stop = min(offset + batch_size, len(self.preview_segments))
            for seg_index in range(offset, stop):
                x1, y1, x2, y2, kind, line_no = self.preview_segments[seg_index]
                ax, ay = xy(x1, y1)
                bx, by = xy(x2, y2)
                completed = seg_index < done_n
                if kind == "travel":
                    color = "#999999" if not completed else "#4c9b77"
                    item = c.create_line(ax, ay, bx, by, fill=color, width=1, dash=(3, 3))
                else:
                    color = "#168447" if completed else "#e87512"
                    item = c.create_line(ax, ay, bx, by, fill=color, width=2)
                self.preview_items.append(item)
            if stop < len(self.preview_segments):
                self._preview_draw_after_id = self.root.after(1, lambda: draw_batch(stop))
            else:
                self._preview_draw_after_id = None
                self._preview_status = f"Ready ({len(self.preview_segments):,} moves)"
                self._refresh_monitor_labels()
                if self.preview_points:
                    sx0, sy0 = xy(*self.preview_points[0])
                    c.create_oval(sx0 - 5, sy0 - 5, sx0 + 5, sy0 + 5, fill="#1769aa", outline="white", width=1)
                    c.create_text(sx0 + 7, sy0 - 8, text="START", anchor="sw", fill="#1769aa", font=("Arial", 8, "bold"))
                self._update_count_text()
                self._draw_live_marker()
        draw_batch(0)

    def _draw_live_marker(self):
        """Actual GRBL-reported live machine position, independent of the planned path cursor."""
        c = self.preview_canvas
        c.delete("live")
        pv = self._pv
        pos = self.machine_position
        if not pv or pos.get("X") is None or pos.get("Y") is None:
            return
        mx = pv["left"] + (pos["X"] - pv["xmin"]) * pv["scale"]
        my = pv["top"] + pv["bed_h"] - (pos["Y"] - pv["ymin"]) * pv["scale"]
        c.create_oval(mx - 6, my - 6, mx + 6, my + 6, fill="#d62728", outline="white", width=2, tags="live")
        c.create_text(mx + 8, my + 8, text="LIVE", anchor="nw", fill="#d62728", font=("Arial", 8, "bold"), tags="live")

    def refresh_preview_progress(self):
        """Incremental progress update (no full redraw) so big vector files stay responsive."""
        n = min(self.preview_progress_index, len(self.preview_items))
        if n < self._drawn_progress:
            self.draw_preview()
            return
        c = self.preview_canvas
        for i in range(self._drawn_progress, n):
            kind = self.preview_segments[i][4]
            c.itemconfig(self.preview_items[i], fill="#4c9b77" if kind == "travel" else "#168447")
        self._drawn_progress = n
        self._update_count_text()
        self._draw_live_marker()

    def send_raw(self, data):
        with self.serial_lock:
            if not self.ser or not self.ser.is_open:
                raise RuntimeError("Arduino USB connected nahi hai.")
            self.ser.write(data)
            self.ser.flush()

    def send_command(self, command):
        command = command.strip()
        if not command:
            return False
        try:
            if command in ("!", "~", "?") or command == "\\x18":
                self.send_raw(command.encode("ascii"))
            else:
                self.send_raw((command + "\\n").encode("ascii", errors="ignore"))
            self.log(f">> {command}" if command != "\\x18" else ">> [soft reset Ctrl-X]")
            return True
        except Exception as e:
            self.log(f"Command error: {e}")
            self.disconnect_arduino(silent=True)
            return False


    def send_manual_command(self):
        cmd = self.command_var.get().strip()
        self.command_var.set("")
        self.send_command(cmd)

    def jog(self, axis, direction):
        if self.sender_busy:
            self.log("G-code chal raha hai; manual jog abhi blocked hai.")
            return
        if not self.ser or not self.ser.is_open:
            messagebox.showwarning("Arduino", "Pehle Arduino USB connect karein.")
            return
        try:
            distance = abs(float(self.jog_var.get()))
            if distance <= 0 or distance > 10:
                raise ValueError
        except ValueError:
            messagebox.showwarning("Jog distance", "0.1 se 10 mm ke beech increment chunen.")
            return
        target = None
        if axis == "Z":
            if not self.z_reference_set:
                messagebox.showwarning("Z Reference", "Pehle 'Set Z Reference' dabakar current Z position ko zero set karein.")
                return
            target = self.z_position_from_reference + (distance * direction)
            if target < -40 or target > 40:
                messagebox.showwarning("Z Travel Limit", "Z axis reference se -40 mm se +40 mm ke bahar nahi ja sakti.")
                return
        try:
            feed = int(float(self.speed_vars[axis].get()))
        except ValueError:
            feed = 0
        if feed < 1 or feed > 3000:
            messagebox.showwarning("Speed", "Speed 1–3000 mm/min rakhein.")
            return
        amount = distance * direction
        if not self.send_command(f"G21 G91 G1 {axis}{amount:g} F{feed}"):
            return
        if not self.send_command("G90"):
            return
        if axis == "Z":
            self.z_position_from_reference = target
            self.z_range_label.config(text=f"Z jog requested: {target:.1f} mm  |  allowed: -40 to +40 mm (verify actual position)")

    def adjust_axis_speed(self, axis, delta):
        try:
            current = int(float(self.speed_vars[axis].get()))
        except (ValueError, TypeError):
            current = 300 if axis != "Z" else 200
        new_speed = max(1, min(3000, current + delta))
        self.speed_vars[axis].set(str(new_speed))
        self.apply_axis_speed(axis, previous=current)

    def apply_axis_speed(self, axis, previous=None):
        try:
            speed = int(float(self.speed_vars[axis].get()))
            if speed < 1 or speed > 3000:
                raise ValueError
        except ValueError:
            messagebox.showwarning("Speed", "Speed 1–3000 mm/min rakhein.")
            return
        setting = {"X": 110, "Y": 111, "Z": 112}[axis]
        old_value = previous if previous is not None else getattr(self, "_last_speed_values", {}).get(axis, speed)
        self.send_command(f"${setting}={speed}")
        if not hasattr(self, "_last_speed_values"):
            self._last_speed_values = {}
        self._last_speed_values[axis] = speed
        if hasattr(self, "speed_value_labels") and axis in self.speed_value_labels:
            self.speed_value_labels[axis].configure(text=f"Purani value: {old_value} | Nayi value: {speed} (request bheji gayi)")
        self.log(f"{axis} max rate: {old_value} → {speed} mm/min; GRBL ${setting}.")

    # ---------- G-code sender ----------
    @staticmethod
    def estimate_job_area(lines):
        """Estimate XY drawing bounds from common GRBL G0/G1/G2/G3 coordinate words."""
        x = y = 0.0
        absolute = True
        unit_scale = 1.0  # G21 = mm; G20 = inches
        xs, ys = [x], [y]
        for line in lines:
            clean = line.upper()
            if re.search(r"(?:^|\s)G90(?:\s|$)", clean):
                absolute = True
            if re.search(r"(?:^|\s)G91(?:\s|$)", clean):
                absolute = False
            if re.search(r"(?:^|\s)G20(?:\s|$)", clean):
                unit_scale = 25.4
            if re.search(r"(?:^|\s)G21(?:\s|$)", clean):
                unit_scale = 1.0
            words = {m.group(1): float(m.group(2)) * unit_scale for m in AXIS_XY_RE.finditer(clean)}
            if "X" in words:
                x = words["X"] if absolute else x + words["X"]
            if "Y" in words:
                y = words["Y"] if absolute else y + words["Y"]
            xs.append(x)
            ys.append(y)
        width = max(xs) - min(xs)
        height = max(ys) - min(ys)
        return width, height, width * height

    # ---------- G-code file controls ----------
    def choose_gcode(self):
        path = filedialog.askopenfilename(
            title="Select GRBL G-code",
            filetypes=[("G-code files", "*.gcode *.nc *.tap *.txt"), ("All files", "*.*")]
        )
        if path:
            self.gcode_path = path
            self.file_label.config(text=os.path.basename(path))
            self.job_source = "file"
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    preview_lines = self.parse_gcode_lines(f)
                width, height, area = self.estimate_job_area(preview_lines)
                self.job_info_label.config(
                    text=f"Lines: {len(preview_lines)}   XY bounds: {width:.1f} × {height:.1f} mm ({area:.1f} mm²) approx")
                self.build_preview_path(preview_lines)
                self.preview_hint.config(text="START = shuruaat | Hara = complete drawing | Orange = baaki path | Grey dashed = pen-up travel | Red LIVE = actual machine position. Preview G-code interpretation par aadharit hai.")
            except Exception as exc:
                self.job_info_label.config(text="Lines/Area: estimate unavailable")
                self.log(f"File info estimate error: {exc}")
            self.log(f"G-code selected: {path}")

    def run_gcode(self):
        if not self.ser or not self.ser.is_open:
            messagebox.showwarning("Arduino", "Pehle Arduino USB connect karein.")
            return
        if self.sender_busy:
            messagebox.showinfo("G-code", "G-code pehle se chal raha hai.")
            return
        if not self.gcode_path:
            self.choose_gcode()
            if not self.gcode_path:
                return
        try:
            with open(self.gcode_path, "r", encoding="utf-8", errors="ignore") as f:
                lines = self.parse_gcode_lines(f)
            if not lines:
                raise ValueError("File mein G-code lines nahi mili.")
            self.gcode_lines = lines
        except Exception as e:
            messagebox.showerror("G-code file", str(e))
            return

        self.job_source = "file"
        self.review_gcode_before_run(self.gcode_lines, os.path.basename(self.gcode_path))

    def _read_grbl_reply(self, timeout=30):
        deadline = time.time() + timeout
        while not self.stop_sender.is_set():
            if self.pause_sender.is_set():
                # Feed hold can legitimately delay "ok" for a long time; do not time out while paused.
                deadline = time.time() + timeout
            if time.time() >= deadline:
                break
            with self.serial_lock:
                if not self.ser or not self.ser.is_open:
                    raise RuntimeError("USB connection lost.")
                raw = self.ser.readline()
            if raw:
                text = raw.decode("utf-8", errors="replace").strip()
                if text:
                    self.ui(self.log, f"<< {text}")
                    low = text.lower()
                    if low == "ok" or low.startswith("error:") or low.startswith("alarm:"):
                        return text
            else:
                time.sleep(0.02)
        if self.stop_sender.is_set():
            return "STOPPED"
        raise TimeoutError("GRBL se reply nahi mila (timeout).")

    def _drain_planner_for_stop(self):
        """Wait for all already-accepted GRBL motion to finish before saving a stop checkpoint.

        GRBL G4 P0 is a planner synchronization barrier. This is deliberately used only
        for a graceful stop so normal drawing throughput is not slowed line-by-line.
        """
        if not self.ser or not self.ser.is_open:
            raise RuntimeError("USB disconnect: GRBL planner completion cannot be verified.")
        with self.serial_lock:
            self.ser.write(b"G4 P0\\n")
            self.ser.flush()
        self.ui(self.log, ">> G4 P0 [planner drain before graceful stop]")
        reply = self._read_grbl_reply(timeout=120)
        if reply == "STOPPED" or reply.lower().startswith(("error:", "alarm:")):
            raise RuntimeError(f"GRBL planner drain failed: {reply}. Check machine position before any resume.")
        self._read_position_during_job()
        completed = int(getattr(self, "_last_completed_lines", 0))
        if completed > 0:
            self._save_checkpoint(completed, self.gcode_lines[completed - 1])
        self.ui(self.log, "GRBL planner queue drained. Graceful stop checkpoint position refreshed.")

    def _send_gcode_worker(self):
        try:
            total = len(self.gcode_lines)
            start_index = getattr(self, "_job_start_index", 0)
            for index, line in enumerate(self.gcode_lines[start_index:], start=start_index + 1):
                if self.stop_sender.is_set():
                    break
                if self.graceful_stop.is_set():
                    self._drain_planner_for_stop()
                    break
                while self.pause_sender.is_set() and not self.stop_sender.is_set():
                    time.sleep(0.1)
                if self.stop_sender.is_set():
                    break
                if self.graceful_stop.is_set():
                    self._drain_planner_for_stop()
                    break
                if not getattr(self, "_job_auto_send", True):
                    self._single_step_event.clear()
                    self.ui(self.log, f"Auto Send OFF: line {index} ready; manual next-line mode active.")
                    while not self._single_step_event.wait(0.1):
                        if self.stop_sender.is_set() or self.graceful_stop.is_set():
                            break
                    if self.stop_sender.is_set() or self.graceful_stop.is_set():
                        break
                # ACK-gated auto sender: each line is accepted before the next line is sent.
                with self.serial_lock:
                    if not self.ser or not self.ser.is_open:
                        raise RuntimeError("USB connection lost.")
                    self.ser.write((line + "\n").encode("ascii", errors="ignore"))
                    self.ser.flush()
                self.ui(self.log, f"[{index}/{total}] >> {line}")
                reply = self._read_grbl_reply(timeout=60)
                self._buffer_bytes = 0
                self._buffer_status = "ACK received"
                self.ui(self._refresh_monitor_labels)
                if reply == "STOPPED":
                    break
                low = reply.lower()
                if low.startswith("alarm:"):
                    self.ui(self.show_machine_state, reply.upper())
                    raise RuntimeError(f"GRBL ALARM {reply[6:].strip()} at line {index}: machine state/position verify karein; automatic resume nahi kiya gaya.")
                if low.startswith("error:"):
                    self.ui(self.show_machine_state, "Error", f"G-code line {index}: {reply}. Command syntax, units, feed aur supported GRBL command check karein.")
                    raise RuntimeError(f"GRBL command error at line {index}: {reply}")
                # Track modal distance mode and feed so a live Z insertion can restore G90/G91.
                if re.search(r"\bG90\b", line):
                    self.job_absolute_mode = True
                if re.search(r"\bG91\b", line):
                    self.job_absolute_mode = False
                fm = re.search(r"\bF\s*(\d+(?:\.\d*)?|\.\d+)", line)
                if fm:
                    self.job_last_feed = float(fm.group(1))
                self._execute_pending_runtime_z()
                self._last_completed_lines = index
                self._read_position_during_job()
                self._save_checkpoint(index, line)
                percent = (index / max(1, total)) * 100
                # Segments are tied to their source line number, so progress follows the real G-code line.
                self.preview_progress_index = bisect.bisect_right(self.preview_seg_lines, index)
                self.ui(self.update_progress, percent, index, total)
                self.ui(self.refresh_preview_progress)
            if self.stop_sender.is_set() or self.graceful_stop.is_set():
                completed = self._last_completed_lines
                self.ui(self.announce, f"Graceful stop: GRBL planner drain ke baad line {completed}/{total} par sender ruka. Resume se pehle saved position aur pen height physically verify karein.")
                self.ui(lambda: self.z_range_label.config(text="Stopped at line boundary — verify pen/position before resume"))
            else:
                width, height, area = self.estimate_job_area(self.gcode_lines)
                self.ui(self.announce, f"Drawing Completed / Complete Work. {total} lines complete. Drawing area lagbhag {width:.1f} by {height:.1f} millimeter, yani {area:.1f} square millimeter.")
                try:
                    if os.path.exists(self.checkpoint_path):
                        os.remove(self.checkpoint_path)
                except OSError:
                    pass
                self.ui(lambda: self.z_range_label.config(text="Z reference needed — set current Z as 0"))
        except Exception as e:
            self.ui(self.announce, f"G-code error: {e}")
        finally:
            self.sender_busy = False
            self._buffer_bytes = 0
            self._buffer_status = "Idle"
            self._processing_status = "Idle"
            self.pause_sender.clear()
            self.ui(self._refresh_monitor_labels)
            self.ui(self._set_job_file_visual, "idle")

    def _set_job_file_visual(self, state):
        label = self.file_label.cget("text")
        label = re.sub(r"^(▶ RUNNING: |Ⅱ PAUSED: )", "", label)
        if state == "running":
            self.file_label.configure(text=f"▶ RUNNING: {label}", foreground=GREEN)
        elif state == "paused":
            self.file_label.configure(text=f"Ⅱ PAUSED: {label}", foreground="#b36b00")
        else:
            self.file_label.configure(text=label, foreground=DARK)

    def _save_checkpoint(self, completed, last_line):
        try:
            snapshot = self.checkpoint_path + ".job.gcode"
            if not os.path.isfile(snapshot):
                raise FileNotFoundError("Exact reviewed G-code snapshot missing.")
            if not getattr(self, "_job_snapshot_sha256", None):
                with open(snapshot, "rb") as sf:
                    self._job_snapshot_sha256 = hashlib.sha256(sf.read()).hexdigest()
            payload = {
                "source": self.job_source,
                "path": snapshot,
                "original_path": self.gcode_path if self.job_source == "file" else None,
                "line": int(completed),
                "total": len(self.gcode_lines),
                "last_acknowledged_line": int(completed),
                "last_acknowledged_gcode": str(last_line),
                "snapshot_sha256": self._job_snapshot_sha256,
                "position": self.machine_position,
                "modal_note": "GRBL ok confirms command acceptance, not necessarily physical motion completion. Verify machine position and GRBL state before resuming.",
                "feed_override_percent": self.feed_override_percent,
                "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "note": "Checkpoint is informational. After reset/power loss/alarm/disconnect, verify or home axes before manual resume."
            }
            temp_checkpoint = self.checkpoint_path + ".tmp"
            with open(temp_checkpoint, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp_checkpoint, self.checkpoint_path)
        except Exception as exc:
            self.ui(self.log, f"Checkpoint save failed: {exc}")


    def update_progress(self, percent, completed, total):
        self.progress_var.set(percent)
        self.progress_label.config(
            text=f"Progress: {percent:.1f}%  ({completed}/{total} lines)")

    def send_next_line(self):
        event = getattr(self, "_single_step_event", None)
        if self.sender_busy and event is not None:
            event.set()
            self.log("Manual next-line permission di gayi.")
        else:
            self.log("Manual next-line mode active nahi hai.")

    def pause_gcode(self):
        if self.sender_busy:
            self.pause_sender.set()
            self.send_command("!")
            self.ui(self._set_job_file_visual, "paused")
            self.log("Feed hold requested.")
        else:
            self.log("Koi G-code run nahi ho raha.")

    def resume_gcode(self):
        if self.sender_busy:
            self.pause_sender.clear()
            self.send_command("~")
            self.ui(self._set_job_file_visual, "running")
            self.log("Resume requested.")

    def stop_gcode(self):
        if self.sender_busy:
            if not messagebox.askyesno("Safe Stop", "Stop request current line ke GRBL acknowledgement ke baad sender ko rokegi, lekin GRBL planner mein pehle se accepted moves abhi bhi chal sakte hain. Isliye ise physical motion stop ya exact resume point na samjhein. Position/pen physically verify kiye bina checkpoint resume na karein. Rokein?"):
                return
            was_paused = self.pause_sender.is_set()
            self.graceful_stop.set()
            with self.runtime_control_lock:
                self.pending_runtime_z = None
            self.pause_sender.clear()
            if was_paused:
                self.send_command("~")  # allow the in-flight command to finish before stopping at its acknowledgement boundary
            self.log("STOP requested: current command acknowledgement ke baad safely rukega; GRBL alarm/reset nahi bheja jayega.")
        else:
            self.log("Koi G-code run nahi ho raha.")

    def resume_stopped_job(self):
        if self.sender_busy:
            messagebox.showinfo("Resume", "Pehle current job ko pause ya stop karein.")
            return
        if not self.ser or not self.ser.is_open:
            messagebox.showwarning("Arduino", "Resume se pehle Arduino connect karein.")
            return
        try:
            with open(self.checkpoint_path, "r", encoding="utf-8") as f:
                saved = json.load(f)
            snapshot = saved.get("path")
            if saved.get("source") not in ("file", "console") or not snapshot or not os.path.isfile(snapshot):
                raise ValueError("Saved reviewed G-code snapshot nahi mila. Original file ko dobara load/review karein.")
            with open(snapshot, "rb") as sf:
                snapshot_bytes = sf.read()
            expected_hash = saved.get("snapshot_sha256")
            actual_hash = hashlib.sha256(snapshot_bytes).hexdigest()
            if not expected_hash or actual_hash != expected_hash:
                raise ValueError("Checkpoint G-code snapshot badal gayi hai ya corrupt hai. Resume roka gaya.")
            lines = self.parse_gcode_lines(snapshot_bytes.decode("utf-8", errors="strict").splitlines())
            completed = int(saved.get("last_acknowledged_line", saved.get("line", 0)))
            if int(saved.get("total", len(lines))) != len(lines):
                raise ValueError("Checkpoint aur saved G-code line count match nahi karte.")
            if completed < 0 or completed >= len(lines):
                raise ValueError("Checkpoint line number valid nahi hai ya job pehle hi complete ho chuka hai.")
            pos = saved.get("position") or {}
            confirm = (f"Checkpoint: {completed}/{len(lines)} lines acknowledged.\\n"
                       f"Saved position: X={pos.get('X')} Y={pos.get('Y')} Z={pos.get('Z')}\\n\\n"
                       "Important: GRBL ka ok command accept hone ka signal hai; har baar physical movement complete hone ka proof nahi. "
                       "Machine ko physically inspect karein, current position/work zero/pen height verify karein. "
                       "Power loss, reset, alarm ya homing ke baad bina position verify kiye resume na karein.\\n\\n"
                       "Verified position ke baad next line se resume karein?")
            if not messagebox.askyesno("Confirm Resume", confirm):
                return
            self.gcode_path = saved.get("original_path") or snapshot
            self.gcode_lines = lines
            self.job_source = saved.get("source", "file")
            self._job_snapshot_sha256 = actual_hash
            self.file_label.config(text=(os.path.basename(self.gcode_path) if self.job_source == "file" else "Console G-code (saved checkpoint)"))
            self.build_preview_path(lines)
            self.preview_progress_index = bisect.bisect_right(self.preview_seg_lines, completed)
            self.update_progress(completed / max(1, len(lines)) * 100, completed, len(lines))
            self._start_job(lines, start_index=completed)
            self.log(f"Resume started from line {completed + 1}; last acknowledged line was {completed}.")
        except Exception as exc:
            messagebox.showerror("Resume checkpoint", str(exc))


    def close_app(self):
        if self.sender_busy:
            if not messagebox.askyesno(
                "Close AVM Plotter",
                "G-code job active hai. App band karne se USB communication ruk jayega aur machine position uncertain ho sakti hai. "
                "Close karne se pehle Feed Hold + GRBL Soft Reset bhejna hai? Physical E-stop/power switch bhi zarurat par use karein."
            ):
                return
            self.stop_sender.set()
            self.graceful_stop.set()
            self.pause_sender.clear()
            with self.runtime_control_lock:
                self.pending_runtime_z = None
            try:
                self.send_raw(b"!")
                time.sleep(0.12)
                self.send_raw(bytes([0x18]))
                self.log("App close: Feed Hold + GRBL Soft Reset sent. Position UNVERIFIED; physical inspection/homing required.")
            except Exception as exc:
                self.log(f"App close stop command failed: {exc}. Physical power cutoff use karein.")
        self.stop_sender.set()
        self._monitor_stop.set()
        if self._monitor_after_id is not None:
            try:
                self.root.after_cancel(self._monitor_after_id)
            except Exception:
                pass
        try:
            self.disconnect_arduino(silent=True)
        finally:
            self.root.destroy()



def main():
    root = tk.Tk()
    app = AVMAI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
