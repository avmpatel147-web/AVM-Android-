package com.avm.plotter

import android.app.ActivityManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Process
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.max

private const val ACTION_USB_PERMISSION = "com.avm.plotter.USB_PERMISSION"
private data class XY(val x: Double, val y: Double, val penDown: Boolean)

class MainActivity : ComponentActivity() {
    private lateinit var usbManager: UsbManager
    private var port: UsbSerialPort? = null
    private var connectionStatus by mutableStateOf("USB disconnected")
    private var machineStatus by mutableStateOf("Waiting for GRBL")
    private var consoleText by mutableStateOf("")
    private var positionText by mutableStateOf("X —   Y —   Z —")
    private var selectedFileName by mutableStateOf("No G-code selected")
    private var gcodeLines = listOf<String>()
    private var previewPoints by mutableStateOf(listOf<XY>())
    private var senderJob: Job? = null
    @Volatile private var sending = false
    @Volatile private var paused = false
    @Volatile private var stopRequested = false
    private var sentCount by mutableIntStateOf(0)
    private var totalCount by mutableIntStateOf(0)
    private var jogStep by mutableFloatStateOf(1f)
    private var xFeed by mutableIntStateOf(700)
    private var yFeed by mutableIntStateOf(700)
    private var zFeed by mutableIntStateOf(300)
    private var elapsedText by mutableStateOf("00:00")
    private var etaText by mutableStateOf("—")
    private var systemText by mutableStateOf("RAM: reading…")
    private var settingsText by mutableStateOf("GRBL settings not loaded. Tap Read \$\$.")
    private var zoom by mutableFloatStateOf(1f)
    private var selectedUri: Uri? = null
    private var jobStartedAt = 0L
    private var snapshotFile: File? = null
    private val prefs by lazy { getSharedPreferences("avm_job", MODE_PRIVATE) }
    private val grblReplies = LinkedBlockingQueue<String>()

    private val openGcode = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            selectedUri = uri
            selectedFileName = uri.lastPathSegment ?: "G-code selected"
            lifecycleScope.launch(Dispatchers.IO) {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                val parsed = parseLines(text)
                withContext(Dispatchers.Main) {
                    gcodeLines = parsed; totalCount = parsed.size; sentCount = 0
                    previewPoints = buildPreview(parsed)
                    appendLog("Loaded ${parsed.size} G-code lines; preview generated")
                }
            }
        }
    }

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ACTION_USB_PERMISSION) {
                val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
                if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && device != null) openDevice(device)
                else connectionStatus = "USB permission denied"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        registerUsbReceiver()
        restoreCheckpoint()
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    AVMScreen(
                        connectionStatus, machineStatus, positionText, selectedFileName,
                        sentCount, totalCount, consoleText, jogStep, xFeed, yFeed, zFeed,
                        elapsedText, etaText, systemText, settingsText, previewPoints, zoom,
                        onConnect = { discoverUsb() }, onDisconnect = { disconnect() },
                        onOpen = { openGcode.launch(arrayOf("*/*")) },
                        onPlay = { startJob(false) }, onPause = { pauseJob() }, onResume = { resumeJob() }, onStop = { stopJob() },
                        onJog = { axis, dir -> jog(axis, dir) }, onStep = { jogStep = it },
                        onFeed = { axis, value -> when(axis) { "X" -> xFeed=value; "Y" -> yFeed=value; else -> zFeed=value } },
                        onPenUp = { send("G21 G91 G0 Z1\n") }, onPenDown = { send("G21 G91 G0 Z-1\n") },
                        onHome = { send("\$H\n") }, onUnlock = { send("\$X\n") }, onStatus = { send("?\n") },
                        onConsole = { send(it.trim() + "\n") }, onSettings = { readSettings() },
                        onResumeSaved = { resumeSavedJob() }, onZoom = { zoom = (zoom * it).coerceIn(0.25f, 8f) }, onFit = { zoom = 1f },
                        onFeedOverride = { sendRealtime(it) }
                    )
                }
            }
        }
        lifecycleScope.launch {
            while (true) {
                if (port != null) send("?\n")
                refreshSystemStats()
                if (sending && jobStartedAt > 0) {
                    val elapsed = ((System.currentTimeMillis()-jobStartedAt)/1000).toInt()
                    elapsedText = formatTime(elapsed)
                    val rate = if (sentCount > 0 && elapsed > 0) sentCount.toDouble()/elapsed else 0.0
                    val remain = if (rate > 0) ((totalCount-sentCount)/rate).toInt() else -1
                    etaText = if (remain >= 0) formatTime(remain) else "Calculating…"
                }
                delay(1000)
            }
        }
    }

    private fun parseLines(raw: String): List<String> = raw.lineSequence().map { it.substringBefore(';').trim() }
        .filter { it.isNotBlank() && !it.startsWith("(") }.toList()

    private fun buildPreview(lines: List<String>): List<XY> {
        var x=0.0; var y=0.0; var down=false
        val out=ArrayList<XY>()
        val rx=Regex("([XY])\\s*(-?\\d+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE)
        for (line in lines) {
            if (Regex("\\bZ\\s*-", RegexOption.IGNORE_CASE).containsMatchIn(line)) down=true
            if (Regex("\\bZ\\s*\\+?\\d", RegexOption.IGNORE_CASE).containsMatchIn(line)) down=false
            for (m in rx.findAll(line)) {
                val v=m.groupValues[2].toDoubleOrNull() ?: continue
                if (m.groupValues[1].equals("X",true)) x=v else y=v
            }
            if (Regex("\\b[GM]0?\\b|\\bG1\\b", RegexOption.IGNORE_CASE).containsMatchIn(line)) out.add(XY(x,y,down))
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun registerUsbReceiver() {
        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(usbReceiver, filter)
    }

    private fun discoverUsb() {
        val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (drivers.isEmpty()) { connectionStatus = "No USB serial device. Check OTG cable."; return }
        val device = drivers.first().device
        if (usbManager.hasPermission(device)) openDevice(device) else {
            val pi = PendingIntent.getBroadcast(this, 0, Intent(ACTION_USB_PERMISSION).setPackage(packageName), PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            usbManager.requestPermission(device, pi)
        }
    }

    private fun openDevice(device: UsbDevice) {
        try {
            val driver = UsbSerialProber.getDefaultProber().probeDevice(device) ?: error("Unsupported USB serial device")
            val connection = usbManager.openDevice(device) ?: error("Could not open USB device")
            val p = driver.ports.first(); p.open(connection)
            p.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            port = p; connectionStatus = "Connected • 115200 baud"; machineStatus = "Connected; checking GRBL"
            appendLog("USB connected. GRBL 115200 8-N-1")
            lifecycleScope.launch(Dispatchers.IO) { readLoop(p) }
            send("\n"); send("?\n")
        } catch (e: Exception) { connectionStatus = "Connect error: ${e.message}" }
    }

    private suspend fun readLoop(p: UsbSerialPort) {
        val buffer=ByteArray(1024)
        while (port === p) try {
            val n=p.read(buffer,500)
            if(n>0){
                val s=String(buffer,0,n)
                s.lineSequence().map{it.trim()}.filter{it=="ok" || it.startsWith("error:")}.forEach{grblReplies.offer(it)}
                withContext(Dispatchers.Main){
                    appendLog(s.trim())
                    if(s.contains("<")){
                        machineStatus=s.substringAfter('<').substringBefore('>')
                        Regex("[WM]Pos:([^|>]+)").find(s)?.groupValues?.getOrNull(1)?.let{positionText=it}
                    }
                    if(s.contains("$")) settingsText=(settingsText+"\n"+s.trim()).takeLast(5000)
                }
            }
        } catch(e:Exception){ withContext(Dispatchers.Main){appendLog("USB read stopped: ${e.message}")}; break }
    }

    private fun sendRealtime(value:Int){ val p=port?:run{appendLog("Not connected");return}; lifecycleScope.launch(Dispatchers.IO){try{p.write(byteArrayOf(value.toByte()),1000)}catch(e:Exception){withContext(Dispatchers.Main){appendLog("Realtime write error: ${e.message}")}}} }
    private fun send(data:String){ val p=port?:run{appendLog("Not connected");return}; lifecycleScope.launch(Dispatchers.IO){try{p.write(data.toByteArray(),1500)}catch(e:Exception){withContext(Dispatchers.Main){appendLog("USB write error: ${e.message}")}}} }
    private fun jog(axis:String,direction:Int){
        val speed=when(axis){"X"->xFeed;"Y"->yFeed;else->zFeed}
        val mm=(jogStep.coerceAtMost(40f)*direction)
        send("\$J=G91 G21 ${axis}${mm} F${speed}\n")
    }
    private fun readSettings(){settingsText="Reading GRBL \$\$…";send("\$\$\n")}
    private fun startJob(resume:Boolean){
        if(port==null){appendLog("Connect to GRBL first");return}
        if(gcodeLines.isEmpty()){appendLog("Choose a G-code file first");return}
        if(sending)return
        if(senderJob?.isActive == true){appendLog("Previous sender is still stopping. Wait a moment before starting/resuming.");return}
        if(!resume){sentCount=0; jobStartedAt=System.currentTimeMillis();
            snapshotFile=File(filesDir,"avm_active_job.gcode")
            snapshotFile!!.writeText(gcodeLines.joinToString("\n"))
            prefs.edit().putString("snapshot",snapshotFile!!.absolutePath).putString("sha",sha256(snapshotFile!!.readBytes())).putInt("total",gcodeLines.size).putInt("completed",0).apply()
        } else jobStartedAt=System.currentTimeMillis()
        stopRequested=false;paused=false;sending=true
        senderJob=lifecycleScope.launch(Dispatchers.IO){
            for(i in sentCount until gcodeLines.size){
                while(paused && sending) delay(100)
                if(!sending || stopRequested) break
                val line=gcodeLines[i]
                grblReplies.clear()
                try{port?.write((line+"\n").toByteArray(),2000)}catch(e:Exception){withContext(Dispatchers.Main){appendLog("Write failed: ${e.message}")};break}
                val reply=grblReplies.poll(20,TimeUnit.SECONDS)
                if(reply==null || reply.startsWith("error:")){
                    withContext(Dispatchers.Main){appendLog("Safety pause: GRBL reply timeout/error at line ${i+1}: $reply")}
                    paused=true;break
                }
                withContext(Dispatchers.Main){sentCount=i+1;saveCheckpoint()}
            }
            sending=false
            withContext(Dispatchers.Main){
                if(sentCount>=totalCount) {prefs.edit().putBoolean("finished",true).apply();appendLog("Job transmission complete. Verify physical motion before next operation.")}
                else appendLog("Sender stopped/paused at acknowledged line $sentCount. Position must be verified before resume.")
            }
        }
    }
    private fun pauseJob(){paused=true;send("!\n");appendLog("Feed hold requested. Wait for machine to settle.")}
    private fun resumeJob(){if(!sending && sentCount<totalCount){send("~\n");startJob(true)}else{paused=false;send("~\n");appendLog("Cycle start requested")}}
    private fun stopJob(){stopRequested=true;paused=false;send("!\n");sending=false;appendLog("Stop/hold requested. This is not emergency stop; verify machine position before resume.")}
    private fun saveCheckpoint(){prefs.edit().putInt("completed",sentCount).putInt("total",totalCount).putString("filename",selectedFileName).apply()}
    private fun restoreCheckpoint(){
        val path=prefs.getString("snapshot",null)?:return
        val f=File(path);if(!f.exists())return
        try{
            val bytes=f.readBytes();if(sha256(bytes)!=prefs.getString("sha",null)){appendLog("Saved job snapshot hash mismatch; resume disabled");return}
            gcodeLines=parseLines(String(bytes));snapshotFile=f;totalCount=gcodeLines.size;sentCount=prefs.getInt("completed",0).coerceIn(0,totalCount)
            selectedFileName=prefs.getString("filename","Saved AVM job")?:"Saved AVM job";previewPoints=buildPreview(gcodeLines)
        }catch(e:Exception){appendLog("Checkpoint restore error: ${e.message}")}
    }
    private fun resumeSavedJob(){
        if(port==null){appendLog("Connect to GRBL first");return}
        if(sentCount>0)appendLog("WARNING: confirm actual machine position, GRBL modal state, offsets and pen state before resuming.")
        startJob(true)
    }
    private fun sha256(b:ByteArray)=MessageDigest.getInstance("SHA-256").digest(b).joinToString(""){"%02x".format(it)}
    private fun refreshSystemStats(){try{val am=getSystemService(ACTIVITY_SERVICE) as ActivityManager;val mi=ActivityManager.MemoryInfo();am.getMemoryInfo(mi);val used=(mi.totalMem-mi.availMem)/1048576;val total=mi.totalMem/1048576;systemText="RAM: ${used} / ${total} MB • App CPU time: ${Process.getElapsedCpuTime()/1000}s"}catch(_:Exception){}}
    private fun formatTime(s:Int):String="%02d:%02d".format(s/60,s%60)
    private fun appendLog(s:String){if(s.isNotBlank())consoleText=(consoleText+s+"\n").takeLast(12000)}
    private fun disconnect(){stopRequested=true;paused=false;sending=false;try{port?.close()}catch(_:Exception){};port=null;connectionStatus="USB disconnected"}
    override fun onDestroy(){disconnect();try{unregisterReceiver(usbReceiver)}catch(_:Exception){};super.onDestroy()}
}

@Composable
private fun AVMScreen(
    connection:String,machine:String,position:String,file:String,sent:Int,total:Int,log:String,step:Float,xFeed:Int,yFeed:Int,zFeed:Int,
    elapsed:String,eta:String,system:String,settings:String,points:List<XY>,zoom:Float,
    onConnect:()->Unit,onDisconnect:()->Unit,onOpen:()->Unit,onPlay:()->Unit,onPause:()->Unit,onResume:()->Unit,onStop:()->Unit,
    onJog:(String,Int)->Unit,onStep:(Float)->Unit,onFeed:(String,Int)->Unit,onPenUp:()->Unit,onPenDown:()->Unit,onHome:()->Unit,onUnlock:()->Unit,
    onStatus:()->Unit,onConsole:(String)->Unit,onSettings:()->Unit,onResumeSaved:()->Unit,onZoom:(Float)->Unit,onFit:()->Unit,onFeedOverride:(Int)->Unit
){
    var command by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("AVM PLOTTER",style=MaterialTheme.typography.headlineMedium);Text("Android GRBL Controller • Development build")
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
            Text(connection);Text("Machine: $machine");Text("Position: $position")
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick=onConnect){Text("Connect USB")};OutlinedButton(onClick=onDisconnect){Text("Disconnect")}}
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick=onUnlock){Text("Alarm Unlock \$X")};OutlinedButton(onClick=onStatus){Text("Status ?")};OutlinedButton(onClick=onHome){Text("Home \$H")}}
        }}
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
            Text("MANUAL JOG",style=MaterialTheme.typography.titleLarge)
            Text("Jog step: $step mm (Z limit ±40 mm)")
            Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf(0.1f,1f,2f,5f,10f,40f).forEach{OutlinedButton(onClick={onStep(it)}){Text("$it")}}}
            listOf("X" to xFeed,"Y" to yFeed,"Z" to zFeed).forEach{(axis,speed)->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){OutlinedButton(onClick={onJog(axis,-1)}){Text("$axis −")};Text("$axis  •  $speed mm/min",Modifier.padding(top=13.dp));OutlinedButton(onClick={onJog(axis,1)}){Text("$axis +")}}
                Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){OutlinedButton(onClick={onFeed(axis,(speed-50).coerceAtLeast(50))}){Text("$axis Speed −")};OutlinedButton(onClick={onFeed(axis,speed+50)}){Text("$axis Speed +")}}
            }
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick=onPenUp){Text("Pen UP Z1")};Button(onClick=onPenDown){Text("Pen DOWN Z-1")}}
        }}
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
            Text("G-CODE JOB",style=MaterialTheme.typography.titleLarge);Text(file);Button(onClick=onOpen){Text("Open G-code")}
            Text("Progress: $sent / $total lines • ${if(total>0) (sent*100/total) else 0}%")
            if(total>0)LinearProgressIndicator(progress={sent.toFloat()/total},modifier=Modifier.fillMaxWidth())
            Text("Elapsed: $elapsed   •   Estimated remaining: $eta")
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){Button(onClick=onPlay){Text("Play")};OutlinedButton(onClick=onPause){Text("Pause")};OutlinedButton(onClick=onResume){Text("Resume")};OutlinedButton(onClick=onStop){Text("Stop")}}
            OutlinedButton(onClick=onResumeSaved){Text("Resume saved job (verify position first)")}
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){OutlinedButton(onClick={onFeedOverride(0x91)}){Text("Feed +10%")};OutlinedButton(onClick={onFeedOverride(0x92)}){Text("Feed -10%")};OutlinedButton(onClick={onFeedOverride(0x90)}){Text("Feed Reset")}}
        }}
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
            Text("LIVE PREVIEW",style=MaterialTheme.typography.titleLarge);Text("Parsed XY path • zoom ${"%.2f".format(zoom)}x")
            Canvas(Modifier.fillMaxWidth().height(240.dp).background(Color(0xFFF4F4F4),RoundedCornerShape(8.dp))){
                if(points.size>1){val minX=points.minOf{it.x}.toFloat();val maxX=points.maxOf{it.x}.toFloat();val minY=points.minOf{it.y}.toFloat();val maxY=points.maxOf{it.y}.toFloat();val sx=(size.width-20f)/max(1f,maxX-minX);val sy=(size.height-20f)/max(1f,maxY-minY);val scale=minOf(sx,sy)*zoom
                    val path=Path();points.forEachIndexed{i,p->val xx=10f+(p.x.toFloat()-minX)*scale;val yy=size.height-10f-(p.y.toFloat()-minY)*scale;if(i==0)path.moveTo(xx,yy)else path.lineTo(xx,yy)};drawPath(path,Color(0xFF2457A7),style=androidx.compose.ui.graphics.drawscope.Stroke(width=2f))
                }
            }
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(onClick={onZoom(1.25f)}){Text("Zoom +")};OutlinedButton(onClick={onZoom(0.8f)}){Text("Zoom −")};OutlinedButton(onClick=onFit){Text("Fit")}}
        }}
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
            Text("GRBL SETTINGS",style=MaterialTheme.typography.titleLarge);OutlinedButton(onClick=onSettings){Text("Read \$\$ Settings")};Text(settings,style=MaterialTheme.typography.bodySmall)
        }}
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
            Text("SYSTEM MONITOR",style=MaterialTheme.typography.titleLarge);Text(system)
        }}
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
            Text("GRBL CONSOLE",style=MaterialTheme.typography.titleLarge)
            OutlinedTextField(command,{command=it},Modifier.fillMaxWidth(),label={Text("Command e.g. \$\$ or \$100")})
            Button(onClick={onConsole(command);command=""}){Text("Send Command")};Text(log,style=MaterialTheme.typography.bodySmall)
        }}
        Text("Safety: this development build is not machine-certified. Test with pen lifted and a small file. Pause/Stop are not emergency stops. Use physical E-stop/power cutoff. After reset, disconnect, alarm or power loss, verify/home axes and check offsets/modal state before resuming.",style=MaterialTheme.typography.bodySmall)
    }
}
