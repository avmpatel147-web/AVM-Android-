# AVM Plotter Android — Development Project

यह आपकी `AVM_Plotter_SystemMonitor_Improved.py` और AVM के पहले बताए गए controller requirements के आधार पर बनाया जा रहा native Android project है। यह **अभी final/complete APK नहीं है** और वास्तविक AVM machine पर certified नहीं है। Tkinter/pyserial desktop app को सीधे APK में convert नहीं किया जा सकता; Android UI तथा USB communication को Kotlin में port करना पड़ता है।

## इस build में implement किए गए Android modules

- Android USB Host / OTG device discovery और permission flow
- GRBL USB serial: 115200 baud, 8-N-1
- Live GRBL status polling और MPos/WPos status text
- G-code document picker और line parsing
- Sequential G-code sender: प्रत्येक line के बाद `ok`/`error:` acknowledgement wait
- Play, Feed Hold Pause (`!`), Cycle Start Resume (`~`), Stop/hold request
- X/Y/Z jog, configurable jog increment, separate X/Y/Z jog feed settings
- Z jog increment capped at 40 mm per jog command
- Pen UP (`Z1`) / Pen DOWN (`Z-1`), Home (`$H`), Alarm Unlock (`$X`)
- Manual GRBL console, `$$` settings read view
- G-code XY preview with zoom in/out and fit
- Line count, completion percentage, elapsed time and estimated remaining time
- Internal reviewed-job snapshot, SHA-256 check and basic acknowledged-line checkpoint restore
- Basic Android RAM/app CPU-time monitor
- GRBL 1.1 feed override real-time commands (+10%, -10%, reset)

## अभी बाकी / पूर्ण parity के लिए आवश्यक modules

इनको complete किए बिना इस ऐप को आपके Python app का full replacement नहीं कहा जा सकता:

1. Desktop Python app के सभी UI panels और सभी exact feature behaviours का one-to-one port.
2. Photo-to-G-code पूरा workflow: Centerline, Outline, Fill, Pencil Sketch, Detailed Sketch, Combination; brightness/contrast/darkness/sharpness/detail/size/spacing/shading controls; original-vs-preview compare; Auto Compare & Improve.
3. Full machine-area analyzer, G-code preflight review, warnings, Auto-Fit XY, test drawing generator.
4. Robust GRBL planner-synchronized stop and recovery; USB loss/reset/alarm recovery; exact machine position, work offsets, modal state, pen state और Z reference safe resume.
5. Console-pasted G-code job mode, Auto Flow ON/OFF, runtime pen command queue, feed override persistence.
6. Complete GRBL settings browser with descriptions, editable values, validation and settings history.
7. Live preview में current-position marker, executed/unexecuted path colouring, pan, persistent zoom and full progress-state restoration.
8. Device compatibility, USB reconnect, Android background-service/foreground notification, long-job screen-lock and thermal/battery handling.
9. Real machine testing: DRV8825/UNO/CNC Shield, GRBL 1.1h, endstops, Z pen mechanism and large G-code files.

## Safety — बहुत जरूरी

- इस development build का sender अभी full GRBL planner-buffer protocol नहीं है; यह simple line-by-line `ok` wait करता है।
- Current checkpoint केवल acknowledged line count और G-code snapshot hash रखता है। यह actual physical position, GRBL planner queue, WCO/G92 offsets, modal state, Z pen height या endstop/home state का पूर्ण सुरक्षित checkpoint नहीं है।
- इसलिए USB disconnect, reset, alarm, power loss या Stop के बाद blind Resume न करें। पहले machine position, homing, work zero, pen state और GRBL status verify करें।
- Stop/Pause emergency stop नहीं हैं। Emergency में physical E-stop/power cutoff इस्तेमाल करें।
- पहली test: pen उठाकर, कम speed पर, खाली area में छोटा 20 mm square; उसके बाद ही pen-down test.

## APK build

इस workspace में Android SDK/Gradle build toolchain उपलब्ध नहीं था, इसलिए यहां compiled `.apk` बनाकर verify नहीं किया जा सका। GitHub Actions workflow `.github/workflows/build-apk.yml` रखा है। Project को GitHub repository में push करने के बाद **Actions → Build AVM Android APK → Run workflow** चलाने पर debug APK artifact मिलेगा।

Local build requirements:
- Android Studio with Android SDK Platform 35 and Build Tools 35
- JDK 17
- Android Gradle Plugin 8.7.3 compatible Gradle
- Open this folder in Android Studio and run `:app:assembleDebug`

APK बनने के बाद Android phone में install करने के लिए unknown-app installation permission देना पड़ सकता है। Arduino connection के लिए USB OTG cable/adapter और Android USB Host support जरूरी है.
